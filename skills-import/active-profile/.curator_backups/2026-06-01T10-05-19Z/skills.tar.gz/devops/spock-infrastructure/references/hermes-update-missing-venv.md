# Hermes Update — Missing Venv Recovery

**Date:** 2026-05-28
**Symptom:** `hermes update` fails with "Python interpreter not found at `venv/bin/python3`"
**Context:** Source checkout at `~/hermes-agent-ui` had been updated via `git pull` previously, but the `venv/` directory was missing (possibly deleted during cleanup or never recreated after a Python upgrade).

## Error transcript

```
error: Failed to inspect Python interpreter from active virtual environment
  Caused by: Python interpreter not found at `/home/thadd/hermes-agent-ui/venv/bin/python3`
→ Updating Python dependencies...
  ⚠ Optional extras failed, reinstalling base dependencies and retrying extras individually...
✗ Update failed: Command '['/home/thadd/.local/bin/uv', 'pip', 'install', '-e', '.']'
   returned non-zero exit status 2.
```

## Fix steps

1. **Create venv from the source checkout:**
   ```bash
   cd ~/hermes-agent-ui
   python3 -m venv venv
   ```

2. **Activate and upgrade pip:**
   ```bash
   source venv/bin/activate
   pip install --upgrade pip
   ```

3. **Install base package:**
   ```bash
   uv pip install -e .
   ```
   (If `uv` is not in the venv, use the system-installed `~/.local/bin/uv` — it auto-detects the active venv.)

4. **Install optional extras:**
   ```bash
   uv pip install -e ".[all]"
   ```

5. **Verify:**
   ```bash
   hermes --version   # → "Up to date"
   ```

## Key pitfall

The `hermes update` script assumes the venv exists at `./venv/` relative to the source checkout. If it doesn't, the fallback logic tries `uv pip install -e .` but without a venv context, which fails. Manually recreating the venv is faster than debugging the update script.

## Environment at time of fix

- OS: WSL (Ubuntu on Windows 11)
- Python: 3.14.4 (system at `/usr/bin/python3`)
- Hermes source: `/home/thadd/hermes-agent-ui` (editable install)
- Active profile: `plc-coder`
- `uv` location: `~/.local/bin/uv`
