---
name: spock-infrastructure
description: End-to-end operations for the Spock/Hermes persona and environment — agent identity recovery, workspace migration (especially from OpenClaw), infrastructure health checks, secure GitHub backups, and WSL-Windows interoperability.
trigger:
  - backup agent state
  - migrate workspace
  - import from openclaw
  - hermes claw migrate
  - spock identity
  - recover hermes agent
  - wsl windows file
  - windows shortcut from wsl
  - cross filesystem file
  - update hermes
  - upgrade hermes
  - hermes update failed
---

# Spock Infrastructure Operations

## Overview

This umbrella skill covers all operational tasks for maintaining, migrating, backing up, and recovering the Spock (Hermes Agent) persona and environment. It spans identity recovery, workspace migration, infrastructure health, and WSL-Windows file interop.

## 1. Workspace Migration

### Preferred Path: Built-in `hermes claw migrate`

Hermes has a built-in OpenClaw importer. Use this first.

**1. Stop both services**
```bash
hermes gateway stop
pkill -f openclaw
```

**2. Preview with dry-run**
```bash
hermes claw migrate --source /mnt/c/Users/thadd/.openclaw --dry-run
```

**3. Run migration**
```bash
hermes claw migrate \
  --source /mnt/c/Users/thadd/.openclaw \
  --preset full \
  --migrate-secrets \
  --overwrite \
  --yes
```

**4. Post-migration cleanup**
```bash
# Remove deprecated key
hermes config set terminal.cwd /mnt/c/Users/thadd/.openclaw/workspace
sed -i '/^MESSAGING_CWD=/d' ~/.hermes/.env

# Verify secrets transferred
cat ~/.hermes/.env | grep -E 'API_KEY|TOKEN'

# Restart gateway
hermes gateway restart
```

### Manual Fallback

When the built-in importer fails:

1. **Locate source**: `find /mnt/c/Users/ -maxdepth 3 -type d -iname '*openclaw*'`
2. **Read core persona files** in priority: `SOUL.md`, `USER.md`, `AGENTS.md`, `HEARTBEAT.md`, `TOOLS.md`, `MEMORY.md`
3. **Map agent configs to cron jobs** using the `cronjob` tool
4. **Read recent memory** (latest 5-7 daily files) for context catch-up
5. **Save key facts** to Hermes persistent memory

**WSL Path Conventions:**
- `C:\Users\thadd\Desktop\Portfolio Positions` → `/mnt/c/Users/thadd/Desktop/Portfolio Positions`
- Space-containing paths: use quotes in terminal, escaped in cron prompts
- Git workspace: set `--workdir` on cron jobs to project directory

**What migrates**: SOUL.md, MEMORY.md, USER.md, .env secrets, config.yaml, skills, daily memory.
**What does NOT migrate**: cron jobs, MCP servers, Discord/Slack/Signal settings.

## 2. Identity Recovery

Create a lean GitHub recovery repo containing everything to reconstruct Spock from scratch.

**Include** (from `/mnt/c/Users/thadd/.openclaw/workspace/`):
- `SOUL.md`, `MEMORY.md`, `USER.md`, `IDENTITY.md`, `AGENTS.md`, `TOOLS.md`, `SECURITY.md`, `REGISTRY.md`, `DREAMS.md`, `HEARTBEAT.md`, `HOME_PC_SETUP.md`, `PLC_SPAWN.md`
- `README.md` with step-by-step recovery instructions
- `~/.hermes/config.yaml` (tokens redacted)

**Exclude**: Daily briefs, whale watch reports, trading arena outputs, large binaries, active tokens, session logs.

**Recovery template (`README.md`)**:
```markdown
# Spock Recovery
1. git clone https://github.com/AntisystemOG/HermestoSpock.git
2. mkdir -p /mnt/c/Users/thadd/.openclaw/workspace
3. cp *.md /mnt/c/Users/thadd/.openclaw/workspace/
4. cp config.yaml ~/.hermes/config.yaml
5. hermes gateway restart
6. Tell agent: "Become Spock. Read SOUL.md, MEMORY.md, USER.md, IDENTITY.md."
```

## 3. Secure GitHub Backup

Backup `.hermes/` to a private GitHub repo without leaking secrets.

**1. Write `.gitignore` BEFORE first commit:**
```gitignore
.env
.env.*
auth.json
auth.lock
*.key
*.pem
*.db
*.sqlite
*.sqlite3
sessions/
backups/
state-snapshots/
audio_cache/
*.log
.DS_Store
temp_*.*
```

**2. Sanitize `config.yaml`:**
```bash
cd ~/.hermes
python3 -c "
import re
with open('config.yaml', 'r') as f:
    text = f.read()
text = re.sub(r'(api_key|session_key|brave_api_key|token|password|secret_key):\s*\"[^\"]*\"', r'\1: \"\"', text)
with open('config.yaml', 'w') as f:
    f.write(text)
"
grep -rn 'api_key.*=\|api_key:.*\"[^\"]\+\"' config.yaml | grep -v ': \"\"'  # should return NOTHING
```

**3. One-shot credential helper (no hardcoded PAT in remote URL):**:
```bash
cat > /tmp/git-cred-helper.sh <<'EOF'
#!/bin/bash
case "$1" in
  get)
    echo "protocol=https"; echo "host=github.com"
    echo "username=<GITHUB_USERNAME>"; echo "password=<YOUR_PAT>"
    ;;
  store|erase) : ;;
esac
EOF
chmod 700 /tmp/git-cred-helper.sh
cd ~/.hermes
git remote add origin https://github.com/<OWNER>/<REPO>.git 2>/dev/null || true
GIT_ASKPASS=/tmp/git-cred-helper.sh git push -u origin main --force
rm -f /tmp/git-cred-helper.sh
```

## 4. WSL-Windows File Interop

### Path Translation Rules

| Windows path | WSL equivalent |
|-------------|----------------|
| `C:\Users\thadd` | `/mnt/c/Users/thadd` |
| `C:\Users\thadd\Desktop` | `/mnt/c/Users/thadd/Desktop` |
| `C:\Users\thadd\.claude` | `/mnt/c/Users/thadd/.claude` |

**Critical distinction**: The Hermes agent runtime lives in `/home/thadd/.hermes/` (WSL home), but the WebUI and many project files live under `/mnt/c/Users/thadd/` (Windows home).

### Finding Folders Across Boundaries

When the user says "I just created a folder":
1. Search WSL home: `find /home/thadd -maxdepth ...`
2. Search Windows: `find /mnt/c/Users/thadd -maxdepth ... -iname "*folder*"`
3. Use `-iname` for case-insensitive search — Windows filesystem is case-insensitive but WSL is case-sensitive

### Creating Windows Shortcuts from WSL

**Method 1: PowerShell `-File` (Recommended)**
```bash
cat > "/mnt/c/Users/thadd/Desktop/create_shortcut_temp.ps1" << 'EOF'
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\Users\thadd\Desktop\My Shortcut.lnk")
$Shortcut.TargetPath = "C:\Users\thadd\.claude\projects"
$Shortcut.IconLocation = "C:\Users\thadd\Desktop\spock-icon.ico,0"
$Shortcut.WorkingDirectory = "C:\Users\thadd\Desktop"
$Shortcut.Save()
EOF
/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe -ExecutionPolicy Bypass -File "C:\Users\thadd\Desktop\create_shortcut_temp.ps1"
rm "/mnt/c/Users/thadd/Desktop/create_shortcut_temp.ps1"
```

**Key WScript.Shell properties**:
| Property | Purpose |
|----------|---------|
| `TargetPath` | What the shortcut opens |
| `IconLocation` | `"path\\to\\icon.ico,0"` |
| `WorkingDirectory` | Start-in directory |

**Method 2: Quick `-Command` (escape `$` with `\$`)**
```bash
powershell.exe -Command "\$WshShell = New-Object -ComObject WScript.Shell; \$lnk = \$WshShell.CreateShortcut('C:\\Users\\thadd\\Desktop\\My Shortcut.lnk'); \$lnk.IconLocation = 'C:\\Users\\thadd\\Desktop\\spock-icon.ico,0'; \$lnk.Save()"
```

### Copying Projects for Dev Agents

Claude Code stores projects at `C:\Users\<user>\.claude\projects`. Use `rsync -av --exclude='node_modules' --exclude='.git' --exclude='build' --exclude='dist'` for transfers.

### Common Pitfalls

- **Case sensitivity**: `"CODE Projects"` and `"Code Projects"` are different in WSL. Always search with `-iname`.
- **`find` timeout**: `/mnt/c/` is very large. Use `-maxdepth` or `ls | grep`.
- **PowerShell not found**: Use absolute path `/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe`.
- **Script location for `-File`**: Must be on a Windows-accessible path (`/mnt/c/...`). `/tmp/` is invisible to `powershell.exe`.

## 5. Infrastructure Health

See `references/infrastructure-health-checklist.md` for the full structured health check.

Key checks:
- **Gateway**: `hermes gateway status` or `curl http://127.0.0.1:8000/health`
- **WebUI**: `curl http://127.0.0.1:8648/health`
- **Ollama token**: `curl -H "Authorization: Bearer $OLLAMA_API_KEY" https://ollama.com/v1/models`
- **Memory DB**: `hermes memory list`
- **Cron jobs**: `hermes cron list`
- **Orphaned processes**: `ps aux | grep "hermes_bridge\|agent-bridge"`

## 6. Safe Hermes Updates (Preserve Customizations)

`hermes update` pulls the latest commits and reinstalls dependencies, but it can fail if the venv is missing or stale. Always back up the active profile first.

**Pre-update checklist:**
1. **Export the active profile** — captures skills, memory, config, auth, cron jobs:
   ```bash
   hermes profile export <profile-name>
   # produces /home/thadd/<profile-name>.tar.gz
   ```
2. **Note the current version** — `hermes --version`
3. **Check gateway status** — `hermes gateway status` (update will restart it)

**Running the update:**
```bash
hermes update
```

**Common failure: missing venv**
- `hermes update` may fail with "Python interpreter not found at `venv/bin/python3`"
- This happens when the repo was cloned but the venv was never created or was deleted
- **Fix:** recreate venv and reinstall manually:
  ```bash
  cd ~/hermes-agent-ui   # or wherever the source lives
  python3 -m venv venv
  source venv/bin/activate
  pip install --upgrade pip
  uv pip install -e ".[all]"   # base + all extras
  ```

**Post-update verification:**
```bash
hermes --version              # should say "Up to date"
hermes profile show <name>      # skills count, .env, SOUL.md should all be present
hermes skills list | wc -l      # skill count should match pre-update
hermes memory status            # built-in memory should be active
hermes gateway status           # confirm running after restart
```

**What survives the update:**
- `~/.hermes/profiles/<name>/` — entire profile directory (skills, memory, config, auth, cron)
- `~/.hermes/.env` — root-level secrets
- `~/.hermes/config.yaml` — root config

**What does NOT survive:**
- The source checkout at `~/hermes-agent-ui/` is overwritten by `git pull`
- Any uncommitted local changes are stashed and restored, but review `git status` after

**If the update fails mid-way:**
1. Restore from the exported tar.gz: `hermes profile import /home/thadd/<profile>.tar.gz`
2. Or manually recreate the venv and run `uv pip install -e ".[all]"` from the source dir

### Safe Merge with Uncommitted Spock Customizations

**Trigger:** `git merge origin/main` aborts because `AppSidebar.vue` or `SessionListItem.vue` are dirty.

**Do not stash on a detached HEAD.** User had an old detached HEAD from a prior merge. The correct sequence:
1. `git checkout main` (moving from detached HEAD back to local branch)
2. `git stash -u -m "Spock customizations pre-merge"`
3. `git merge origin/main`
4. After merge, inspect working tree to confirm customizations survived
5. If the Spock Guardian hook claims it restored them, verify independently (don't trust the hook blindly)
6. Pop stash only if the merge obliterated the customizations; drop once confirmed redundant

**What this session proved:** Merging v0.6.4 → v0.6.6 (36 commits, 152 files, 17480 insertions, 1463 deletions) resulted in **zero merge conflicts**. The stash was unnecessary in retrospect — Spock customizations in `AppSidebar.vue` and `SessionListItem.vue` were uncommitted changes on `main` that did not conflict with upstream.

### Non-destructive WebUI git update workflow

The user prefers `git merge` over `git reset --hard` to avoid destroying local state. Follow this sequence when `git pull` shows divergent branches:

1. **Check divergence first** (don't assume fast-forward):
   ```bash
   git log --oneline HEAD..origin/main   # commits we would gain
   git log --oneline origin/main..HEAD   # commits we would lose
   ```
2. **If local is behind, merge:**
   ```bash
   git merge origin/main
   ```
3. **If merge conflicts occur**, resolve or abort — never force.
4. **If local has uncommitted changes**, stash first: `git stash && git merge origin/main && git stash pop`
5. **After merge**, rebuild and restart server.

**Never use `git reset --hard origin/main` without explicit user approval.** The user blocked this during the May 2026 WebUI update session.

---

## 7. Gateway Troubleshooting — Stale Python Module Imports

**Symptom:** `ImportError: cannot import name 'X' from 'hermes_constants'` even though the constant is present in the source file on disk.

**Root cause:** The `hermes-gateway.service` is a long-running Python daemon. Python caches imported modules in memory for the lifetime of the process. If `hermes_constants.py` (or any shared module) is updated on disk after the gateway started, new conversation worker sessions spawned by that gateway still inherit the **stale in-memory module**, not the updated disk version.

**Why clearing `__pycache__` is insufficient:**
1. The `.pyc` bytecode caches are only read on initial import.
2. Once loaded, the module object lives in `sys.modules` inside the gateway process.
3. Every new worker is forked or spawned from the gateway, inheriting its `sys.modules`.

**Diagnostic:**
```bash
# Check gateway age — if older than the file modification time, it's stale
systemctl --user status hermes-gateway.service
# Look at "Active since" vs when the code was last updated

# Verify the source IS correct in a fresh process
python3 -c "from hermes_constants import THE_MISSING_CONSTANT; print('OK')"
```

**Resolution:**
```bash
systemctl --user restart hermes-gateway.service
```

**After restart:**
```bash
systemctl --user status hermes-gateway.service
# Confirm new PID and recent "Active since" timestamp
```

**When `/reset` fails:** If a user runs `/reset` in Telegram and the same import error recurs, the problem is upstream in the gateway daemon, not the conversation worker. Restart the gateway — do not restart `__pycache__` deletion loops.

**Prevention:** After any update to shared modules (`hermes_constants.py`, protocol definitions, shared utilities), always restart the gateway service before testing via messaging platforms.

