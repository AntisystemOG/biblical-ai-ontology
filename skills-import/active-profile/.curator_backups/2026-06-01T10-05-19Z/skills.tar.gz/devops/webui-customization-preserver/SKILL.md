---
name: webui-customization-preserver
description: "Preserve and re-apply WebUI customizations (Spock branding, auth, logos, videos) after npm rebuilds or git pulls. Fast, focused, no fluff."
trigger:
  - webui customization lost
  - rebuild wiped logo
  - logo gone after update
  - thinking video missing
  - spock branding reset
  - webui rebrand after build
  - npm run build lost customizations
  - hermes webui update preserve
  - webui customizations
---

# WebUI Customization Preserver

Fast recovery for when `npm run build`, `git pull`, or `hermes update` wipes your WebUI customizations.

## What Gets Lost on Rebuild

| Customization | Why it disappears | Location |
|---|---|---|
| Spock logo (`logo.png`) | Vite copies `public/` to `dist/client/` with content hashing | `packages/client/public/logo.png` |
| Thinking videos | Same — copied to `dist/client/assets/mp4/` with hash | `packages/client/src/assets/thinking-light.mp4` |
| Auth token path | Server code change may read from different path | `~/.hermes/webui/.token` vs `~/.hermes-web-ui/.token` |
| Model cache | Server restart may regenerate `models_cache.json` | `~/.hermes/webui/models_cache.json` |
| Favicon / title | `index.html` in `packages/client/index.html` gets re-templated | `packages/client/index.html` |

## Quick Recovery — One Script

**Step 0: Check if upstream already has your assets**
The WebUI source may already include Spock branding. Always verify before attempting restoration:

```bash
ls -la /home/thadd/hermes-web-ui/packages/client/public/ | grep -E "spock|logo|favicon"
ls -la /home/thadd/hermes-web-ui/packages/client/src/assets/ | grep thinking
```

If `spock-avatar.png`, `logo.png`, and `thinking-*.mp4` are present and have recent timestamps, the upstream already includes your branding. You only need to verify they made it into `dist/` after `npm run build`:

```bash
ls -la /home/thadd/hermes-web-ui/dist/client/logo.png
ls -la /home/thadd/hermes-web-ui/dist/client/assets/mp4/thinking-*.mp4
```

**If assets are missing from upstream**, run the full restore:

## Quick Recovery — One Script

Run this after any `git pull`, `npm install`, or `npm run build`:

```bash
#!/bin/bash
set -e

`/home/thadd/hermes-web-ui`
IMAGES_DIR="/mnt/c/Users/thadd/.hermes/images"

echo "[1/5] Stopping server..."
pkill -f "node.*dist/server/index.js" || true
sleep 2

echo "[2/5] Restoring Spock logo..."
cp "$IMAGES_DIR/logo.png" "$WEBUI_DIR/packages/client/public/logo.png"
cp "$IMAGES_DIR/logo.png" "$WEBUI_DIR/packages/client/src/assets/logo.png"

echo "[3/5] Restoring thinking videos..."
cp "$IMAGES_DIR/startrek badge.mp4" "$WEBUI_DIR/packages/client/src/assets/thinking-light.mp4"
cp "$IMAGES_DIR/startrek badge.mp4" "$WEBUI_DIR/packages/client/src/assets/thinking-dark.mp4"

echo "[4/5] Rebuilding..."
cd "$WEBUI_DIR"
~/node26/bin/npm run build 2>&1 | tail -5

echo "[5/5] Verifying dist output..."
test -f "$WEBUI_DIR/dist/client/logo.png" && echo "  ✓ logo.png in dist"
test -f "$WEBUI_DIR/dist/client/assets/mp4/thinking-"*.mp4 && echo "  ✓ thinking video in dist"

echo ""
echo "Done. Now restart the server WITH NODE_ENV=production:"
echo "  export NODE_ENV=production HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui"
echo "  /home/thadd/node26/bin/node dist/server/index.js"
```

Save as `~/.hermes/profiles/plc-coder/skills/devops/webui-customization-preserver/scripts/restore.sh` and run with `bash restore.sh`.

Save as `~/.hermes/profiles/plc-coder/skills/devops/webui-customization-preserver/scripts/restore.sh` and run with `bash restore.sh`.

## Manual Steps (if script fails)

### 1. Logo

```bash
cp /mnt/c/Users/thadd/.hermes/images/logo.png /home/thadd/hermes-web-ui/packages/client/public/logo.png
cp /mnt/c/Users/thadd/.hermes/images/logo.png /home/thadd/hermes-web-ui/packages/client/src/assets/logo.png
cd /home/thadd/hermes-web-ui && ~/node26/bin/npm run build
```

### 2. Thinking Videos

```bash
cp /mnt/c/Users/thadd/.hermes/images/startrek\ badge.mp4 /home/thadd/hermes-web-ui/packages/client/src/assets/thinking-light.mp4
cp /mnt/c/Users/thadd/.hermes/images/startrek\ badge.mp4 /home/thadd/hermes-web-ui/packages/client/src/assets/thinking-dark.mp4
cd /home/thadd/hermes-web-ui && ~/node26/bin/npm run build
```

### 3. Verify dist

```bash
ls -la /home/thadd/hermes-web-ui/dist/client/logo.png
ls -la /home/thadd/hermes-web-ui/dist/client/assets/mp4/thinking-*.mp4
```

## Auth Token Path Fix

After updates, the server may look for `.token` in a different path. Check both:

```bash
echo "=== Active token ==="
cat ~/.hermes/webui/.token 2>/dev/null || echo "NOT FOUND at ~/.hermes/webui/.token"

echo "=== Legacy token ==="
cat ~/.hermes-web-ui/.token 2>/dev/null || echo "NOT FOUND at ~/.hermes-web-ui/.token"

echo "=== Launcher reads from ==="
grep -o '\.token' /mnt/c/Users/thadd/Desktop/Launch\ Hermes\ WebUI.bat 2>/dev/null || echo "Check .bat manually"
```

If they differ, sync them:

```bash
token=$(cat ~/.hermes/webui/.token)
echo "$token" > ~/.hermes-web-ui/.token
chmod 600 ~/.hermes-webui/.token ~/.hermes-web-ui/.token
```

## Post-Upgrade LLM Config Verification

**v0.6.4 changed API routes.** Old `/api/models` and `/api/providers` moved to `/api/hermes/...`. The client-side store (`app.ts`) already uses the new routes, but direct `curl` checks and any custom scripts must be updated.

| Old Route (pre-0.6.4) | New Route (0.6.4+) |
|---|---|
| `/api/models` | `/api/hermes/available-models` |
| `/api/providers` | `/api/hermes/config/providers` |

**Verify model config survived the upgrade:**

```bash
token=$(cat ~/.hermes/webui/.token)

# Check model config via new route
curl -sf http://localhost:8648/api/hermes/available-models \
  -H "Authorization: Bearer $token" | jq '{default: .default, default_provider: .default_provider}'

# Expected: {"default":"kimi-k2.6","default_provider":"ollama-cloud"}

# Also verify the source of truth — config.yaml on disk
grep -A2 "^model:" ~/.hermes/profiles/$(cat ~/.hermes/active_profile 2>/dev/null || echo default)/config.yaml
```

**If the model or provider was reset**, the WebUI settings panel is the safest place to re-select. The `models_cache.json` at `~/.hermes/webui/models_cache.json` is a cache — the real config lives in `~/.hermes/profiles/<profile>/config.yaml`.

**If missing, re-set via the WebUI settings panel or:**

```bash
token=$(cat ~/.hermes/webui/.token)
curl -sf http://localhost:8648/api/hermes/config/models \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $token" \
  -d '{"default":"kimi-k2.6","provider":"ollama-cloud"}'
```

## Prevention: Post-Build Hook

Add to `package.json` > `scripts`:

```json
{
  "scripts": {
    "build": "vite build && npm run restore-customizations",
    "restore-customizations": "bash scripts/restore-customizations.sh"
  }
}
```

Then create `scripts/restore-customizations.sh`:

```bash
#!/bin/bash
# Runs AFTER vite build, copies custom assets into dist/
cp /mnt/c/Users/thadd/.hermes/images/logo.png dist/client/logo.png
cp /mnt/c/Users/thadd/.hermes/images/startrek\ badge.mp4 dist/client/assets/thinking-light.mp4
cp /mnt/c/Users/thadd/.hermes/images/startrek\ badge.mp4 dist/client/assets/thinking-dark.mp4
```

## Merge Conflict Danger: `AppSidebar.vue`

This file always conflicts during upstream merges because it contains Spock branding (`Spock` text, `alt="Spock"`) while upstream uses `Hermes`.

**The Pitfall (May 2026, v0.6.5 → v0.6.6):**
During an in-progress merge, using `git checkout --theirs packages/client/src/components/layout/AppSidebar.vue` triggers any `post-checkout` git hook. If the hook runs `git checkout HEAD -- AppSidebar.vue` to restore Spock branding, **HEAD is still the old pre-merge commit**, so the file is reverted to the old version — **not** the upstream v0.6.6 version. Adding and committing then embeds the old file into the merge, silently losing upstream navigation fixes (`RouteLinkItem`, `isStoredSuperAdmin`, route key mapping, etc.).

**Correct Resolution Sequence:**
1. After `git merge origin/main` produces a conflict in `AppSidebar.vue`:
2. **DO NOT use `--theirs`** (triggers the revert hook)
3. Instead, manually resolve the conflict markers:
   - Keep upstream's JavaScript/TypeScript logic (imports, computed properties, functions)
   - Keep upstream's template structure (nav items, new route links)
   - Only replace `alt="Hermes"` → `alt="Spock"` and `>Hermes<` → `>Spock<` in the logo section
4. Save, `git add`, `git merge --continue`
5. OR: rename the hook temporarily:
   ```bash
   mv .git/hooks/post-checkout .git/hooks/post-checkout.bak
   git checkout --theirs packages/client/src/components/layout/AppSidebar.vue
   mv .git/hooks/post-checkout.bak .git/hooks/post-checkout
   # Now manually rebrand: sed ...
   ```

**Post-Merge Feature Verification (greppable upstream features):**
```bash
grep "RouteLinkItem" packages/client/src/components/layout/AppSidebar.vue && echo "OK: RouteLinkItem present" || echo "FAIL: missing RouteLinkItem"
grep "isStoredSuperAdmin" packages/client/src/components/layout/AppSidebar.vue && echo "OK: isStoredSuperAdmin present" || echo "FAIL: missing isStoredSuperAdmin"
grep "usePersistentRecord" packages/client/src/components/layout/AppSidebar.vue && echo "OK: usePersistentRecord present" || echo "FAIL: missing usePersistentRecord"
grep "hermes.mcp" packages/client/src/components/layout/AppSidebar.vue && echo "OK: MCP nav present" || echo "FAIL: missing MCP nav"
```

## Verification Checklist (MANDATORY before declaring merge complete)

Run these checks **before** telling the user the update is done:

- [ ] **Check `MessageList.vue` imports `.mp4` not `.gif`:**
  ```bash
  grep -n "thinking.*\.gif" /home/thadd/hermes-web-ui/packages/client/src/components/hermes/chat/MessageList.vue \
    && echo "FAIL: .gif imports found" || echo "OK: no .gif"
  ```
  If this prints anything, STOP — fix `MessageList.vue` first (see "Post-Merge Asset Reference Corruption Check" below).

- [ ] **Verify LLM config survived the upgrade:**
  ```bash
  token=$(cat ~/.hermes/webui/.token)
  curl -sf http://localhost:8648/api/hermes/available-models \
    -H "Authorization: Bearer *** | jq '{default: .default, default_provider: .default_provider}'
  ```
  Expected: `{"default":"kimi-k2.6","default_provider":"ollama-cloud"}`. If wrong, the model/provider may have been reset — re-set via WebUI settings panel.

- [ ] `dist/client/logo.png` exists and is your logo
- [ ] `dist/client/assets/mp4/thinking-*.mp4` exists and is your video
- [ ] `dist/client/assets/` does NOT contain `thinking-*.gif` (upstream may have replaced .mp4 with .gif)
- [ ] `~/.hermes/webui/.token` matches launcher read path
- [ ] Server restarted **with `NODE_ENV=production`**
- [ ] Server restarted with `HERMES_AGENT_BRIDGE_PYTHON` set to Hermes venv Python
- [ ] Login works with existing credentials (not silently using empty dev DB)
- [ ] Health check shows `webui_update_available: false`
  ```bash
  curl -sf http://127.0.0.1:8648/health | grep '"webui_update_available":false'
  ```
  **If true:** The local build is ahead of the npm published version (e.g. `0.6.6` local vs `0.6.5` on npm). Restart the server with `HERMES_WEB_UI_DISABLE_UPDATE_CHECK=true` to suppress the banner. The comparison is `!==`, not `<`, so newer local versions still trigger it.

## Post-Merge Asset Reference Corruption Check

After merging upstream WebUI updates, **git may not flag conflicts** even though upstream changed asset imports in Vue components. The merge auto-adopts upstream imports, replacing your custom `.mp4` with upstream `.gif` files.

**Files to verify after every upstream merge:**

```bash
`/home/thadd/hermes-web-ui`

# Check MessageList.vue imports — upstream may have switched .mp4 → .gif
grep -n "thinking.*\.gif" packages/client/src/components/hermes/chat/MessageList.vue \
  && echo "WARNING: .gif imports detected — need to restore .mp4" \
  || echo "OK: no .gif imports"

# Check for any remaining .gif thinking references anywhere
grep -rn "thinking.*\.gif" packages/client/src/ 2>/dev/null \
  && echo "WARNING: .gif references found in source" \
  || echo "OK: source is clean"
```

**If `.gif` imports are found**, patch `MessageList.vue`:

```bash
# Replace .gif imports with .mp4
sed -i 's/thinking-light\.gif/thinking-light.mp4/g' packages/client/src/components/hermes/chat/MessageList.vue
sed -i 's/thinking-dark\.gif/thinking-dark.mp4/g' packages/client/src/components/hermes/chat/MessageList.vue

# Replace <img> with <video> element
sed -i 's/<img$/<video/g' packages/client/src/components/hermes/chat/MessageList.vue
sed -i 's/alt=""//g' packages/client/src/components/hermes/chat/MessageList.vue
sed -i 's/class="thinking-video">/class="thinking-video"\n          autoplay\n          loop\n          muted\n          playsinline\n        \/>/g' packages/client/src/components/hermes/chat/MessageList.vue
```

**Better: use the exact patch from this session:**

In `packages/client/src/components/hermes/chat/MessageList.vue`:
1. Change imports:
   ```typescript
   import thinkingImageLight from "@/assets/thinking-light.mp4";
   import thinkingImageDark from "@/assets/thinking-dark.mp4";
   ```
2. Change `<img>` to `<video>`:
   ```html
   <video
     :src="isDark ? thinkingImageDark : thinkingImageLight"
     autoplay
     loop
     muted
     playsinline
     aria-hidden="true"
     class="thinking-video"
   />
   ```

Then rebuild:
```bash
cd /home/thadd/hermes-web-ui && ~/node26/bin/npm run build
```

**Verify dist has only .mp4:**
```bash
find dist/client/assets -name "thinking-*.gif" -type f 2>/dev/null \
  && echo "FAIL: .gif in dist" || echo "OK: no .gif in dist"
find dist/client/assets -name "thinking-*.mp4" -type f 2>/dev/null \
  && echo "OK: .mp4 in dist" || echo "FAIL: no .mp4 in dist"
```

## Post-Update Server Start

**Always use `NODE_ENV=production`** when starting after updates, and **set `HERMES_AGENT_BRIDGE_PYTHON`** to the Hermes venv Python (required for `openai`, `websockets`, and other bridge dependencies).

Also set **`HERMES_WEB_UI_DISABLE_UPDATE_CHECK=true`** to suppress the "update available" banner. This is required when your local build is merged from upstream `main` ahead of the last npm publish — the server fetches the npm registry version (e.g. `0.6.5`) and compares it to your local version (e.g. `0.6.6`). Since `0.6.5 !== 0.6.6`, the banner fires constantly. The env var disables the check entirely.

```bash
pkill -f "node.*dist/server/index.js" || true; sleep 2

unset AUTH_DISABLED
export NODE_ENV=production
export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui
export PORT=8648
export BIND_HOST=0.0.0.0
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3
export HERMES_WEB_UI_DISABLE_UPDATE_CHECK=true
export WORKSPACE_BASE=/mnt/c/Users/thadd/.openclaw/workspace

cd /home/thadd/hermes-web-ui
/home/thadd/node26/bin/node dist/server/index.js \
  >> /home/thadd/.hermes/webui/logs/server.log 2>&1 &

sleep 3
curl -sf http://127.0.0.1:8648/health && echo "Server UP"
```

**Without `NODE_ENV=production`:**
- Server creates a new dev DB at `cwd/packages/server/data/hermes-web-ui.db`
- Your user accounts are NOT migrated
- Login fails because the `users` table is empty
- `.login-lock.json` is created in the wrong location

If you already started without production mode:
1. Stop the server (`pkill -f "node.*dist/server/index.js"`)
2. Clear the wrong DB (optional): `rm /home/thadd/packages/server/data/hermes-web-ui.db`
3. Restart with `NODE_ENV=production`
4. If login still fails, check `references/auth-troubleshooting.md` in the `hermes-web-ui` skill

## Critical: `AUTH_DISABLED` Inheritance Bug

**The Problem (May 2026):**
After a WebUI update, the login page refused all passwords even though the correct credentials were stored in the production DB (`~/.hermes/webui/hermes-web-ui.db`). Additionally, new chat sessions failed with:

```
Error: Failed to initialize OpenAI client: No module named 'openai'
```

The root cause was **two separate environment issues** that combined to disable auth and break the agent bridge:

### 1. `AUTH_DISABLED` Inherited from Parent Shell

The server was launched from a shell that had `AUTH_DISABLED` set (either from a `.bashrc` export, a Desktop launcher `.bat`, or a previous session). When `packages/server/src/services/auth.ts:18` checks for this env var, **any value** (even `0` or `false`) disables username/password auth and returns `"Auth is disabled on this server"`.

**Detection:**
```bash
# Check if AUTH_DISABLED is present in the server's environment
grep -a AUTH_DISABLED /proc/$(pgrep -f "node.*dist/server/index.js")/environ 2>/dev/null | tr '\0' '\n'

# Or check the active login response
curl -sf http://127.0.0.1:8648/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"test","password":"test"}' | jq -r '.message // .error'
# If it says "Auth is disabled on this server", this is the bug
```

**Fix:**
```bash
# Stop the server
pkill -f "node.*dist/server/index.js" || true; sleep 2

# Unset AUTH_DISABLED explicitly (just in case)
unset AUTH_DISABLED

# Restart with NODE_ENV=production AND no AUTH_DISABLED
`/home/thadd/hermes-web-ui`
export NODE_ENV=production
export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui
export PORT=8648
export BIND_HOST=0.0.0.0
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3
/home/thadd/node26/bin/node dist/server/index.js
```

### 2. Server Running Without `NODE_ENV=production`

When the server starts without `NODE_ENV=production` (see Post-Update Server Start section above), it uses a dev DB at `packages/server/data/hermes-web-ui.db` instead of `~/.hermes/webui/hermes-web-ui.db`. The dev DB has an empty `users` table, so every login attempt fails and creates `.login-lock.json` in the wrong location.

**Detection:**
```bash
# Check which DB the server is actually using
lsof -p $(pgrep -f "node.*dist/server/index.js") | grep -i "\.db"
# If it shows packages/server/data/hermes-web-ui.db, it's in dev mode
```

**Fix:**
```bash
# Stop the server
pkill -f "node.*dist/server/index.js" || true; sleep 2

# Clear the lock file that may have been created in the wrong location
rm -f /home/thadd/packages/server/data/.login-lock.json
rm -f /home/thadd/.hermes/webui/.login-lock.json

# Optionally clear the dev DB so it can't confuse things later
rm -f /home/thadd/packages/server/data/hermes-web-ui.db

# Restart with NODE_ENV=production
`/home/thadd/hermes-web-ui`
unset AUTH_DISABLED
export NODE_ENV=production
export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3
/home/thadd/node26/bin/node dist/server/index.js

# Verify login works
curl -sf http://127.0.0.1:8648/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"AntiSyStem","password":"AllisfairinWarandLove"}' | python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if d.get('token') else d.get('error','fail'))"
```

### Prevention Checklist

Before launching the server after any update:

- [ ] `echo $AUTH_DISABLED` — must print nothing (not `0`, not `false`, not empty string)
- [ ] `echo $NODE_ENV` — must print `production`
- [ ] `ls -la ~/.hermes/webui/hermes-web-ui.db` — must exist and be non-empty
- [ ] `ls -la packages/server/data/hermes-web-ui.db` — should NOT exist (or is a stale dev DB)
- [ ] `echo $HERMES_AGENT_BRIDGE_PYTHON` — must point to a Python that has `openai`, `websockets`, etc. installed (typically `/home/thadd/hermes-agent-ui/venv/bin/python3`)

### Permanent Fix: Launcher Scripts

Update your Desktop launchers to explicitly unset `AUTH_DISABLED`:

**`Launch Hermes WebUI.bat` (Windows):**
```batch
@echo off
REM Force auth enabled and production mode
set AUTH_DISABLED=
set NODE_ENV=production
set HERMES_WEB_UI_HOME=C:\Users\thadd\.hermes\webui
set PORT=8648

REM Use WSL to start the server
wsl -d Ubuntu-22.04 -e bash -lic "unset AUTH_DISABLED; export NODE_ENV=production; export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui; export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3; cd /home/thadd/hermes-web-ui-ekko && /home/thadd/node26/bin/node dist/server/index.js"
```

**Linux/WSL shortcut:**
```bash
#!/bin/bash
# Save as ~/bin/start-webui.sh
unset AUTH_DISABLED
export NODE_ENV=production
export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3
export PORT=8648
export BIND_HOST=0.0.0.0

`/home/thadd/hermes-web-ui`
exec /home/thadd/node26/bin/node dist/server/index.js
```

The `unset AUTH_DISABLED` is critical because parent shells (especially if you previously ran the server with auth disabled for debugging) may leak this variable into child processes.

## Bridge Python Module Errors

**Symptoms in server logs:**
```
Failed to initialize OpenAI client: No module named 'openai'
No module named 'websockets'
```

**Root cause:** The WebUI agent bridge spawns Python subprocesses. By default it uses `sys.executable` from the broker process. If the broker is launched with system `python3` (`/usr/bin/python3`), workers inherit that interpreter, which lacks the `openai`, `websockets`, and other packages installed in the Hermes venv.

**Detection:**
```bash
# Check what Python the bridge broker is using
ps aux | grep -E "hermes_bridge.*endpoint" | grep -v grep
# If it shows /usr/bin/python3 or /usr/bin/env python3, it's wrong

# Check what Python workers use after a chat starts
ps aux | grep -E "hermes_bridge.*worker" | grep -v grep
```

**Fix:**
```bash
# Stop the server
pkill -f "node.*dist/server/index.js" || true; sleep 2

# Restart with explicit bridge Python path
`/home/thadd/hermes-web-ui`
unset AUTH_DISABLED
export NODE_ENV=production
export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3
export PORT=8648
export BIND_HOST=0.0.0.0
/home/thadd/node26/bin/node dist/server/index.js
```

**Verify:**
```bash
# After starting a chat, check worker Python path
ps aux | grep -E "hermes_bridge.*worker" | grep -v grep
# Should show: /home/thadd/hermes-agent-ui/venv/bin/python3

# Verify openai is importable in that interpreter
/home/thadd/hermes-agent-ui/venv/bin/python3 -c "import openai; print('openai', openai.__version__)"
```

**Prevention:** Always include `HERMES_AGENT_BRIDGE_PYTHON` in the server start environment. The WebUI update process (`npm run build`) does not preserve or validate this path.

## Profile Switching in WebUI

**Problem:** Selecting a different profile from the WebUI sidebar dropdown does **not** change the profile of the currently open session. The existing session continues to run under its original profile.

**Symptoms:**
- You select `plc-coder` from the dropdown
- Agent responds with wrong persona (`devteam`)  
- Bridge worker logs show `[hermes-bridge-worker:devteam]` instead of `[hermes-bridge-worker:plc-coder]`
- Agent says "I am running under the devteam profile"

**Root cause:** The WebUI stores `profile` per-session in `hermes-web-ui.db`. The dropdown only affects **new sessions**.

**Detection — check DB:**
```bash
python3 -c "
import sqlite3
conn = sqlite3.connect('/home/thadd/.hermes/webui/hermes-web-ui.db')
c = conn.cursor()
c.execute('SELECT id, profile, title, started_at FROM sessions ORDER BY started_at DESC LIMIT 5')
for row in c.fetchall():
    print(f'{row[0]} | profile: {row[1] or \"default\"} | {row[2]}')
conn.close()
"
```
If the active session shows `profile: devteam` (or any profile other than what the dropdown shows), that's the mismatch.

**Detection — check bridge worker logs:**
```bash
tail -20 /home/thadd/.hermes/webui/logs/server.log | grep "bridge-worker"
# Look for: [hermes-bridge-worker:devteam] vs [hermes-bridge-worker:plc-coder]
```

**Fix Option 1 — Start New Chat (Recommended):**
1. Select desired profile from dropdown **first**
2. Click **"New Chat"**
3. This creates a session with the selected profile
4. Bridge spawns a new worker with correct profile

**Fix Option 2 — Update DB directly (preserve session history):**
```bash
python3 -c "
import sqlite3
conn = sqlite3.connect('/home/thadd/.hermes/webui/hermes-web-ui.db')
c = conn.cursor()
# Update specific session
c.execute(\"UPDATE sessions SET profile = 'plc-coder' WHERE id = 'YOUR_SESSION_ID'\")
# Or update all sessions for a profile
c.execute(\"UPDATE sessions SET profile = 'plc-coder' WHERE profile = 'devteam'\")
conn.commit()
print(f'Updated {c.rowcount} session(s)')
conn.close()
"
```

**Caveat:** Updating the DB only fixes the session record. The currently running bridge worker will still be the old profile until a new chat spawns a new worker.

**Fix Option 3 — Restart server + new chat (if worker stuck):**
```bash
pkill -f "node.*dist/server/index.js" || true; sleep 2
unset AUTH_DISABLED
export NODE_ENV=production
export HERMES_WEB_UI_HOME=/home/thadd/.hermes/webui
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/hermes-agent-ui/venv/bin/python3
cd /home/thadd/hermes-web-ui-ekko && /home/thadd/node26/bin/node dist/server/index.js
# Then in WebUI: select correct profile → New Chat
```

**Prevention workflow:**
1. Select profile from dropdown **first**
2. Then click **"New Chat"**
3. Verify agent responds with correct persona

**Full reference:** See `references/profile-switching-workaround.md`

- **`references/local-ollama-provider-setup.md`** — Step-by-step for making a local Ollama server (`http://127.0.0.1:11434`) visible in the WebUI model dropdown. Covers all three server-side registries (PROVIDER_PRESETS, PROVIDER_ENV_MAP, auth exemptions) plus live model fetching and local model installation.

## Session References

- **`references/upstream-merge-v0.6.7.md`** — Notes from merging upstream v0.6.7. The "stash pop fails" pattern: when upstream does NOT reintroduce `RouteLinkItem` or `is="a"`, the working tree already contains the Spock customizations and the stash is redundant — just drop it. No manual conflict resolution needed for this 5-commit release.
- **`references/upstream-merge-0.6.5-0.6.6.md`** — Notes from merging upstream 0.6.5 → 0.6.6. Includes the `post-checkout` hook pitfall that silently reverts `AppSidebar.vue` to the old version, losing upstream features like `RouteLinkItem`, `isStoredSuperAdmin`, and `hermes.mcp` nav. Provides the bypass sequence and feature verification greps.
- **`references/hermes-core-update-with-webui.md`** — How to update the Hermes CLI core (`hermes update --backup --yes`) without touching the WebUI. Covers profile export, gateway kill, auto-stash rollback, venv path verification, and WebUI server restart to pick up the new version string.
- **`references/upstream-merge-0.6.3.md`** — Notes from merging upstream 0.6.3 while preserving Spock branding and auth enforcement. Includes commit-by-commit breakdown, conflict resolution for `AppSidebar.vue`, and post-merge verification checklist.
- **`references/upstream-merge-0.6.4.md`** — Notes from merging upstream 0.6.4. Same conflict pattern in `AppSidebar.vue`, same `.gif` → `.mp4` asset corruption in `MessageList.vue`. Build time ~4 minutes. Server env requirements unchanged.
