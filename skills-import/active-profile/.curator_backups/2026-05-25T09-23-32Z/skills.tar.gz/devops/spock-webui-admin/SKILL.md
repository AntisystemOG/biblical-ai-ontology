---
title: Spock WebUI Administration
name: spock-webui-admin
trigger: |
  Any task involving the Spock WebUI at port 8648 (or custom port): provider
  configuration, model selection, troubleshooting "No LLM provider configured",
  fixing empty model dropdowns, auth/key management for web sessions,
  inspecting/modifying WebUI session state, or cleaning up old/duplicate WebUI
  processes and orphaned state directories.
description: |
  Thad's EKKOLearnAI WebUI is a Node.js/Vue-based application running from
  `/mnt/c/Users/thadd/hermes-web-ui/`. It does NOT read model configuration
  from the CLI agent's running config directly; it caches provider/model state
  in its own JSON files at `~/.hermes/webui/` and exposes REST endpoints for
  configuration. This skill covers how to read and modify that state, manage auth
  tokens, customize UI elements (avatars, branding), and troubleshoot issues.
---

# Spock WebUI Administration

## Architecture

- **Server**: `server.py` from the spock-webui repo. Usually runs via systemd or
  manual start on a configured port (default 8787).
- **State dir**: `~/.spock/webui/` (override with `SPOCK_WEBUI_STATE_DIR` env var).
- **Config source**: Reads `~/.spock/config.yaml` for base settings, but provider
  keys are stored in `~/.spock/.env`.
- **Separate from CLI agent**: The WebUI has its own model cache, session index,
  and settings. Changes via `hermes model` CLI do NOT automatically propagate
  to active WebUI sessions.

## Key State Files

| File | Purpose |
|------|---------|
| `~/.spock/webui/models_cache.json` | `active_provider`, `default_model`, provider groups |
| `~/.spock/webui/settings.json` | WebUI user preferences including `default_model` |
| `~/.spock/webui/sessions/<id>.json` | Per-session model, provider, messages |
| `~/.spock/webui/sessions/_index.json` | Index of all sessions with model/provider fields |
| `~/.spock/.env` | Provider API keys (managed via `/api/providers` POST) |
| `~/.spock/config.yaml` | Base config (shared with CLI agent) |
| `~/.spock/webui/.token` | Auth token for browser auto-login (`?token=...`) |

## REST API Endpoints for Configuration

### GET /api/providers
Returns all providers with `has_key`, `models`, `configurable` flags.

### GET /api/models
Returns the active provider, default model, and grouped model list.
If `active_provider` is null and `default_model` is empty, the UI shows nothing.

### GET /api/settings
Returns WebUI settings including `default_model`, `theme`, `onboarding_completed`.

### POST /api/providers
Set or update a provider API key. Body:
```json
{"provider": "opencode-go", "api_key": "sk-..."}
```
If `api_key` is empty string/null, the key is removed.
Writes to `~/.spock/.env` using the standard env var name for that provider.

### POST /api/default-model
Set the global default model. Body:
```json
{"model": "kimi-k2.6"}
```

## Authentication

The WebUI stores a single auth token at `~/.spock/webui/.token` (600 perms, 64-char hex). The browser shortcut reads this file and appends `?token=<token>` to open the page directly.

### Regenerate token
```bash
# Generate new token
token=$(python3 -c "import secrets; print(secrets.token_hex(32))")
echo "$token" > ~/.hermes-web-ui/.token
chmod 600 ~/.hermes-web-ui/.token

# Also update the legacy path if it exists (some launchers read from here)
cp ~/.hermes-web-ui/.token ~/.hermes/webui/.token 2>/dev/null || true

# Restart server (adjust PID and workdir for your stack)
kill <server_pid>  # or systemctl --user restart hermes-webui.service
# Server auto-reads .token on next startup
```

### Dual token file syndrome
The Hermes WebUI ecosystem has **two token file locations** that can diverge:
- **Server reads**: `~/.hermes/webui/.token` (active)
- **Old launchers read**: `~/.hermes-web-ui/.token` (legacy path, may be stale)

**Critical:** The active token is now at `~/.hermes/webui/.token`. Legacy launchers and
older `.bat` files may still read `~/.hermes-web-ui/.token`. When the server regenerates
its token, it writes **only** to `~/.hermes/webui/.token`, so the legacy file becomes
stale and launchers will pass an expired token.

Always `diff` both files. If they differ, update the launcher `.bat` to read the
correct path.
```bash
# Check both files
diff ~/.hermes/webui/.token ~/.hermes-web-ui/.token 2>/dev/null && echo "Same" || echo "DIFFERENT"

# Fix launcher (Windows batch) to read correct path
# In Launch Hermes WebUI.bat, change:
#   FOR /F "delims=" %%i IN ('wsl cat /home/thadd/.hermes-web-ui/.token') DO set WSLTOKEN=%%i
# To:
#   FOR /F "delims=" %%i IN ('wsl cat /home/thadd/.hermes/webui/.token') DO set WSLTOKEN=%%i
```

### Username/Password Login (User Accounts)

The current WebUI (v0.6.0+) has a **username/password user-account system** stored
in SQLite, independent of the URL `?token=` auth.

**Bootstrap behavior**: When the `users` table is **empty**, the first `POST /api/auth/login`
with *any* username/password calls `bootstrapDefaultSuperAdmin(username, password)`.
The provided credentials become the super_admin account. The `DEFAULT_PASSWORD`
constant in source is only used to set `requiresCredentialChange=true` when the
user's password still matches the hardcoded default.

**Default credentials constant** (source): `DEFAULT_USERNAME = 'admin'`, `DEFAULT_PASSWORD = ***`
These are NOT auto-used for login — they are the baseline against which `requiresCredentialChange`
is evaluated.

**CRITICAL SECURITY CONCERN**: If the `users` table has **0 rows**, ANYONE who hits
the login page first (including on the LAN, since the server binds to `0.0.0.0:8648`)
can claim the super_admin account with arbitrary credentials. Immediately create the
first user after any fresh install, DB migration, or schema reset.

**Create first user directly** (bypasses bootstrap, sets known credentials):
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
pkill -f "node dist/server/index.js" || true
sleep 1

node -e "
const { hashPassword } = require('./packages/server/dist/db/hermes/users-store.js');
(async () => {
  const hash = await hashPassword('YourNewStrongPass123!');
  console.log(hash);
})();
"
# Then insert with sqlite3:
# sqlite3 packages/server/data/hermes-web-ui.db \
#   "INSERT INTO users (username, password_hash, role, status, created_at, updated_at) \
#    VALUES ('AntiSyStem', '<hash>', 'super_admin', 'active', $(date +%s), $(date +%s));"

cd /mnt/c/Users/thadd/hermes-web-ui && node dist/server/index.js &
```

**Direct DB password reset** (when current password is unknown — works only if user exists):
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
pkill -f "node dist/server/index.js" || true
sleep 1

# Generate scrypt hash matching the app's format (scrypt:salt:hash)
hash=$(node -e "
  const crypto = require('crypto');
  const salt = crypto.randomBytes(16).toString('hex');
  const keylen = 64;
  const N = 16384, r = 8, p = 1;
  const hash = crypto.scryptSync('YourNewPass123!', salt, keylen, { N, r, p }).toString('hex');
  console.log('scrypt:' + salt + ':' + hash);
")

sqlite3 packages/server/data/hermes-web-ui.db \
  "UPDATE users SET password_hash='$hash', updated_at=$(date +%s), requires_credential_change=0 WHERE id=1;"

cd /mnt/c/Users/thadd/hermes-web-ui && node dist/server/index.js &
```

**Change password via API** (when logged in with JWT):
```bash
# 1. Obtain JWT
curl -sf http://localhost:8648/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"AntiSyStem","password":"<current>"}' | jq -r '.token'

# 2. Change password
curl -sf http://localhost:8648/api/auth/change-password \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <jwt>" \
  -d '{"currentPassword":"<old>","newPassword":"<new>"}'
```

**Check current users:**
```bash
sqlite3 /mnt/c/Users/thadd/hermes-web-ui/packages/server/data/hermes-web-ui.db \
  "SELECT id, username, role, status, created_at, last_login_at FROM users;"
```

### Auth Database Path: Dev vs Production

The SQLite DB location changes based on `NODE_ENV`:

| Mode | DB Path |
|------|---------|
| `development` (default, no env set) | `packages/server/data/hermes-web-ui.db` (repo-local) |
| `production` | `~/.hermes-web-ui/hermes-web-ui.db` (user home) |

**Critical implication**: If you start the server manually without `NODE_ENV=production`,
user accounts are created in the repo-local DB. A later systemd service that *does*
set `NODE_ENV=production` will use a **different, empty** DB, making the previously
created accounts disappear. Always verify which DB is active:

```bash
# Check which DB the running server has open
lsof -p $(pgrep -f "node dist/server/index.js") | grep hermes-web-ui.db

# Or check the process env
cat /proc/$(pgrep -f "node dist/server/index.js")/environ 2>/dev/null | tr '\0' '\n' | grep NODE_ENV
```

### Disable auth entirely
**WARNING:** This is a major security risk. Auth is enforced on API routes but the SPA shell (`/`) still loads without auth. An attacker on the LAN can load the UI and probe it. Only use this on fully isolated systems.

If you must disable auth, remove `AUTH_DISABLED=1` from `start-server.sh` or the systemd service env. The server checks for this exact string — anything else leaves auth enabled.

### Auth state verification
```bash
cat /proc/$(pgrep -f server.py)/environ 2>/dev/null | tr '\0' '\n' | grep -iE "auth|token|disabled"
cat ~/.spock/webui/.token
```

## Common Issues & Fixes

### "No LLM provider configured" error in chat
**Cause**: Session JSON has `model_provider: null` or the provider has no key.
**Fix chain**:
1. Check current provider state: `GET /api/models`
2. If `active_provider` is null, set a default model: `POST /api/default-model`
3. If provider needs a key, set it: `POST /api/providers`
4. For stale sessions, update the session JSON directly:
   - Edit `~/.hermes/webui/sessions/<id>.json`: set `model` and `model_provider`
   - Also update `~/.hermes/webui/sessions/_index.json` to match
   - Also update `~/.hermes/webui/models_cache.json` for the global default

### Chat fails but /health is OK (agent-bridge Python deps)
**Symptom:** Server starts fine, `/health` returns OK, gateway running, but every chat message fails or shows "disconnected". Browser console shows 500 errors on `/chat-run`.
**Root cause:** The Python agent-bridge worker (spawned by the Node.js server to run `hermes-agent`) is missing Python packages that `hermes-agent` requires. The Node server and bridge broker stay alive, so `/health` is green, but the worker cannot import the agent code.
**Detection:** Check `~/.hermes/profiles/devteam/home/.hermes-web-ui/logs/bridge.log` (or equivalent profile log path) for `No module named 'X'` errors. The error PIDs will match the bridge broker, not the Node server.
**Fix:** See `spock-infrastructure-health` skill, section "Agent-Bridge Python Dependency Health". Typical missing packages: `python-dotenv`, `httpx`. Install with `sudo pip3 install --break-system-packages <pkg>`, then kill all stale bridge processes and restart the WebUI server.
**See also:** `references/agent-bridge-python-deps.md` in `spock-infrastructure-health`.

### Empty model dropdown
**Cause**: `models_cache.json` has `active_provider: null` and `default_model: ""`.
**Fix**: `POST /api/default-model` with the desired model ID. The WebUI will then
build model groups around that provider.

### Provider shows models but "has_key: false"
**Cause**: The provider's API key is not set in `~/.spock/.env`.
**Fix**: `POST /api/providers` with the key. The WebUI writes it to `.env` and
invalidates the model cache.

## Direct State File Editing

When the API is unavailable or you need to bulk-fix many sessions, edit the JSON
state files directly. Important: keep all three files in sync for the same session:

1. `sessions/<id>.json` — `model` and `model_provider` fields
2. `sessions/_index.json` — matching entries for the same session
3. `models_cache.json` — global `active_provider` and `default_model`

Always restart the WebUI or wait for the next page load after direct file edits;
the server caches config in memory.

## Provider ID Reference

| Provider | Env Var | Key Endpoint |
|----------|---------|--------------|
| opencode-go | `OPENCODE_GO_API_KEY` | `/api/providers` |
| opencode-zen | `OPENCODE_ZEN_API_KEY` | `/api/providers` |
| kimi-coding | `KIMI_API_KEY` | `/api/providers` |
| ollama | (none, local) | N/A |
| ollama-cloud | `OLLAMA_API_KEY` | `/api/providers` |
| anthropic | `ANTHROPIC_API_KEY` | `/api/providers` |
| openai | `OPENAI_API_KEY` | `/api/providers` |

## Thad-Specific Paths

Thad's WebUI uses `~/.hermes/webui/` for state (not `~/.spock/webui/`), and the source repo is at `/mnt/c/Users/thadd/hermes-web-ui` (EKKOLearnAI / Spock branded). The active stack is Node.js-based (not Python `server.py`).

Key files in Thad's environment:
| File | Path |
|------|------|
| State dir | `~/.hermes/webui/` |
| Auth token | `~/.hermes/webui/.token` |
| Source repo | `/mnt/c/Users/thadd/hermes-web-ui` |
| Launcher | `/mnt/c/Users/thadd/Desktop/Launch Hermes WebUI.bat` |
| Server start script | `~/.hermes/webui/start-server.sh` (port 8648, AUTH_DISABLED=1) |

## references/
- `references/dual-token-file-paths.md` — Two `.token` file locations and how they diverge.
- `references/session-json-structure.md` — Per-session JSON fields for model/provider.
- `references/git-push-workflow.md` — How to push WebUI customizations to Thad's `spock` fork.
- `references/webui-avatar-customization.md` — Replacing multiavatar with static Spock images, ProfileAvatar component contract, dist-patch technique, stale build pitfall, favicon.ico conversion.
- `references/webui-system-differences.md` — Spock WebUI vs Hermes dashboard vs EKKOLearnAI WebUI.
- `references/api-endpoints.md` — Full endpoint list and response shapes.
- `references/session-2026-05-24-v060-auth-bootstrap-and-db-path.md` — Auth state after upgrade, dev vs production DB paths, AUTH_DISABLED environment leak.
- `references/session-2026-05-24-auth-bypass-vectors.md` — **Four auth bypass vectors discovered and FIXED**: static files public (accepted as SPA requirement), client auto-redirect (removed), URL token extraction (removed), server bearer token fallback (still active for programmatic access). Contains full implementation plan and post-implementation verification.
- `references/provider-ids.md` — Canonical provider IDs and model IDs.
- `references/provider-ids.md` — Canonical provider IDs and model IDs.
- `references/desktop-shortcut-icons.md` — Managing Windows desktop `.lnk` shortcut icons for Spock-branded launchers (PowerShell WScript.Shell, icon cache refresh).
- `references/session-2026-05-24-enabling-auth-after-upgrade.md` — **CRITICAL**: How `AUTH_DISABLED` leaks through parent process env, why `unset` fails, correct `env -u` fix, background process kill pitfall (bash+node double PID), verification commands.
