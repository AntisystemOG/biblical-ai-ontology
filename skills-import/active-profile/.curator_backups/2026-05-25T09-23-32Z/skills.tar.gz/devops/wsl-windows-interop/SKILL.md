---
name: wsl-windows-interop
title: WSL-Windows File Interop
description: |
  Manage files, folders, and shortcuts across WSL and Windows filesystems.
  Covers path translation (/mnt/c/...), PowerShell shortcut creation from WSL,
  case-sensitivity pitfalls, and cross-boundary file operations.
triggers:
  - user asks to move files between WSL and Windows
  - user asks to create a Windows shortcut from WSL
  - user references a Windows path (C:\\Users\\...) while working in WSL
  - file operations involving /mnt/c/ paths
  - finding folders across WSL and Windows boundaries
  - any task involving .claude/, .hermes/, or Windows user profile directories
pitfalls:
  - case_sensitive: WSL filesystem is case-sensitive; Windows is not. "CODE Projects" and "Code Projects" are different directories in WSL but the same on Windows. Always search with `-iname` when unsure.
  - powershell_path: PowerShell.exe must be invoked via absolute path `/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe` from WSL, or via `powershell.exe` if it's in WSL $PATH.
  - ps_script_location: PowerShell `-File` parameter requires the script to exist on a Windows-accessible path (under /mnt/c/). Scripts in /tmp/ or pure WSL paths are invisible to powershell.exe.
  - shortcut_naming: Windows shortcuts (.lnk) created via WScript.Shell from PowerShell need the `.lnk` extension explicitly in the CreateShortcut() call.
related_skills:
  - workspace-migration
  - hermes-desktop-setup
  - hp-project-switcher
---

# WSL-Windows File Interop

## Path Translation Rules

| Windows path | WSL equivalent |
|-------------|----------------|
| `C:\\Users\\thadd` | `/mnt/c/Users/thadd` |
| `C:\\Users\\thadd\\Documents` | `/mnt/c/Users/thadd/Documents` |
| `C:\\Users\\thadd\\Desktop` | `/mnt/c/Users/thadd/Desktop` |
| `C:\\Users\\thadd\\.claude` | `/mnt/c/Users/thadd/.claude` |
| `C:\\Users\\thadd\\.hermes` | `/mnt/c/Users/thadd/.hermes` (note: Hermes runtime is at `/home/thadd/.hermes`) |

**Critical distinction**: The Hermes agent runtime lives at `/home/thadd/.hermes/` (WSL home), but the WebUI and many project files live under `/mnt/c/Users/thadd/` (Windows home). Always verify which `.hermes` or `.claude` the user means.

## Finding Folders Across Boundaries

When the user says "I just created a folder" and you cannot find it:

1. Search WSL home: `find /home/thadd -maxdepth 3 -type d -name "Folder Name"`
2. Search Windows profile: `find /mnt/c/Users/thadd -maxdepth 3 -type d -iname "*folder*"`
3. Search Documents/Desktop specifically with `ls` (faster than `find` on large trees)
4. **Use `-iname` for case-insensitive search** — Windows users often capitalize differently than WSL expects

## Creating Windows Shortcuts from WSL

### Method 1: PowerShell `-File` (Recommended for complex scripts)

Write the PowerShell to a Windows-accessible `.ps1`, then execute it. Avoids quoting hell.

```bash
# Write the PowerShell script to a Windows-accessible path
cat > "/mnt/c/Users/thadd/Desktop/create_shortcut_temp.ps1" << 'EOF'
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\\Users\\thadd\\Desktop\\My Shortcut.lnk")
$Shortcut.TargetPath = "C:\\Users\\thadd\\.claude\\projects"
$Shortcut.IconLocation = "C:\\Users\\thadd\\Desktop\\spock-icon.ico,0"
$Shortcut.WorkingDirectory = "C:\\Users\\thadd\\Desktop"
$Shortcut.Save()
EOF

# Execute via absolute PowerShell path
/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe -ExecutionPolicy Bypass -File "C:\\Users\\thadd\\Desktop\\create_shortcut_temp.ps1"

# Clean up temp script
rm "/mnt/c/Users/thadd/Desktop/create_shortcut_temp.ps1"
```

**Key WScript.Shell properties**:
| Property | Purpose |
|----------|---------|
| `TargetPath` | What the shortcut opens (file, folder, .exe, .bat) |
| `IconLocation` | `"path\\to\\icon.ico,0"` — use `,0` for the first icon in the file |
| `WorkingDirectory` | Start-in directory for the target |
| `WindowStyle` | `1` = normal, `3` = maximized, `7` = minimized |

### Method 2: PowerShell `-Command` (Quick one-liners)

For simple shortcut updates, use `-Command` but **escape `$` with `\`** so bash doesn't interpolate PowerShell variables as empty strings.

```bash
# CORRECT — \$ escapes the $ from bash interpolation
powershell.exe -Command "\$WshShell = New-Object -ComObject WScript.Shell; \$lnk = \$WshShell.CreateShortcut('C:\\Users\\thadd\\Desktop\\My Shortcut.lnk'); \$lnk.IconLocation = 'C:\\Users\\thadd\\Desktop\\spock-icon.ico,0'; \$lnk.Save()"

# WRONG — bash sees $WshShell as an unset bash variable and substitutes empty string
powershell.exe -Command "$WshShell = New-Object -ComObject WScript.Shell; $lnk = ..."
```

**Verification**:
```bash
powershell.exe -Command "\$WshShell = New-Object -ComObject WScript.Shell; \$lnk = \$WshShell.CreateShortcut('C:\\Users\\thadd\\Desktop\\My Shortcut.lnk'); Write-Output ('Icon: ' + \$lnk.IconLocation)"
```

### Method 3: Batch `.bat` shortcut

If the user wants a `.bat` file (not a `.lnk`), there's no native icon property — Windows always shows the generic batch icon. Convert to `.lnk` pointing at the `.bat` and set `IconLocation` on the `.lnk` instead.

## Copying Projects for Dev Agents

When a user says "the Dev Agent will be using this folder":

1. **Claude Code** stores projects at `C:\\Users\\<user>\\.claude\\projects`
2. **Claude Code backups** are at `C:\\Users\\<user>\\.claude\\backups`
3. Always `rsync` with `--exclude='node_modules' --exclude='.git' --exclude='build' --exclude='dist'` to avoid copying massive generated directories
4. Use `cp -r` for small projects; `rsync` for anything with node_modules or build artifacts

## Common Pitfalls

- **"Permission denied" on `/null`**: Typo in redirection `2>/null` instead of `2>/dev/null`. Windows doesn't have `/dev/null` accessible the same way.
- **find timing out**: The Windows filesystem under `/mnt/c/` can be extremely large. Use `-maxdepth` constraints, `ls` with `grep` for targeted directories, or `search_files` tool instead of `find`.
- **powershell.exe not found**: Use the absolute path to the Windows System32 PowerShell v1.0 directory.
- **Script not found from `-File`**: The .ps1 must be on a path Windows can see (under /mnt/c/). Do not use `/tmp/`.

## Verification

Always verify the result:
```bash
ls -la "/mnt/c/Users/thadd/Desktop/My Shortcut.lnk" && echo "SUCCESS" || echo "FAILED"
```