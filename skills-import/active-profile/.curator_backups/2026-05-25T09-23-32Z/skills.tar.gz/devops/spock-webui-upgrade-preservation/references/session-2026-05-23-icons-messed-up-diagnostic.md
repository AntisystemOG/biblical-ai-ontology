# Session Note: "Icons Messed Up" Diagnostic Workflow

**Date:** 2026-05-23
**Trigger:** User ran `openclaw uninstall` (which deleted `/mnt/c/Users/thadd/.openclaw/workspace/`), then reported WebUI icons were "messed up again."

## Actual Root Causes Found

### 1. OpenClaw Uninstall Deleted the Workspace (NOT a WebUI issue)
The uninstall command removed the entire `.openclaw/workspace/` directory. The user conflated this with the WebUI icons being wrong. The workspace was restored from backup:

```bash
mkdir -p /mnt/c/Users/thadd/.openclaw/workspace
cp -r /home/thad/.hermes/webui/openclaw-migrated/* /mnt/c/Users/thadd/.openclaw/workspace/
```

**Backup source:** `/home/thad/.hermes/webui/openclaw-migrated/` — this contains a full copy of the workspace made during initial migration.

### 2. Git Staged Changes That Would Revert Spock Branding
After restoring files, the git repo had staged diffs that would have DOWNGRADED Spock back to generic multiavatar:

- `SessionListItem.vue` — staged to remove `spock-avatar.png`, revert to `multiavatar()`
- `ProfileAvatar.vue` — unstaged diff reverting to `multiavatar()`
- `package.json` — staged monaco-editor downgrade (0.55.1 → 0.53.0)

The Spock Protector post-checkout hook auto-fired during `git checkout` and re-applied branding from backups, but left unstaged modifications. Reverting the staged changes with `git reset HEAD` resolved it.

### 3. Browser Cache (NOT verified as active in this session, but suspected)
Even with correct server assets, the browser may cache old icons. Always tell the user to hard-refresh: **Ctrl+Shift+R** or **Ctrl+F5**.

## Diagnostic Commands

When user reports "icons messed up" or "branding is wrong":

```bash
# Step 1: Check if the SERVER is actually serving wrong assets
curl -sf http://localhost:8648/logo.png -I | grep Content-Length
curl -sf http://localhost:8648/spock-avatar.png -I | grep Content-Length
curl -sf http://localhost:8648/favicon.ico -I | grep Content-Length
# Spock PNG should be ~726,468 bytes. If it's small, it's the wrong asset.

# Step 2: Check git status for staged/unstaged changes that would revert branding
cd /mnt/c/Users/thadd/hermes-web-ui
git status --short
git diff --staged packages/client/src/components/hermes/chat/SessionListItem.vue
git diff packages/client/src/components/hermes/profiles/ProfileAvatar.vue

# Step 3: Check dist/ build timestamp vs. last Spock commit
git log --oneline -5
stat -c "%y" /mnt/c/Users/thadd/hermes-web-ui/dist/client/index.html
# If dist predates the latest Spock commit, the build is stale.

# Step 4: Check if the workspace was deleted
ls -d /mnt/c/Users/thadd/.openclaw/workspace/ 2>/dev/null || echo "WORKSPACE MISSING"
# If missing, restore from /home/thad/.hermes/webui/openclaw-migrated/

# Step 5: Check source vs. dist consistency
sha256sum packages/client/public/logo.png packages/client/public/spock-avatar.png
sha256sum dist/client/logo.png dist/client/spock-avatar.png
# Both pairs should match (same sha256).
```

## Restoration Pattern for Git-Staged Unwanted Changes

If `git status` shows staged changes that revert Spock branding:

```bash
cd /mnt/c/Users/thadd/hermes-web-ui
# Reset specific files to HEAD (removes staged changes)
git reset HEAD -- packages/client/src/components/hermes/chat/SessionListItem.vue
git reset HEAD -- packages/client/src/components/hermes/profiles/ProfileAvatar.vue
git reset HEAD -- package.json

# If working tree files were corrupted by the Spock Protector hook:
git checkout -- packages/client/src/components/hermes/chat/SessionListItem.vue
# (The post-checkout hook will re-fire and re-apply Spock branding from backup.)
```

## Key Lesson

"Icons messed up" is almost NEVER a code bug in this infrastructure. The actual causes, in order of likelihood:
1. **Browser cache** — most common, easiest fix
2. **Git staged/unstaged changes reverting branding** — caused by npm update, upgrade, or Spock Protector hook side effects
3. **Stale dist/ build** — server serving old compiled JS
4. **Workspace deletion** — OpenClaw uninstall or similar destructive operation
5. **Actual code regression** — rare, because Spock Protector is active
