# Session Reference: Spock WebUI v0.5.34 → v0.6.0 Upgrade (2026-05-24)

## Incident Summary
During a standard upstream rebase (`git pull origin main` with rebase enabled), the Spock Guardian `post-rewrite` hook fired and overwrote `AppSidebar.vue` with a stale version from commit `6146e90`. This removed upstream v0.6.0 features including `isSuperAdmin` and the `hermes.performance` sidebar menu item.

## Root Cause
The `post-rewrite` hook previously used `git checkout $SPOCK_COMMIT -- <file>` to restore files. This is safe for a simple checkout, but dangerous during a rebase because:
1. It fires on **every rewritten commit** during the rebase
2. It restores files to the content at commit `6146e90`, which predates upstream features added in v0.5.35–v0.6.0
3. The hook does not check whether a rebase is in progress
4. It creates unstaged changes that pollute the working tree

## Fix Applied
The hook was rewritten to:
- **Skip during rebase**: exits immediately if `rebase-merge/` or `rebase-apply/` directories exist, or if `MERGE_HEAD` is present
- **Use file backups**: copies from `/home/thadd/.hermes/spock-protector/` instead of `git checkout`, preserving the current HEAD content for non-Spock parts of the file
- **Fallback**: if the file backup is missing, falls back to `git checkout f636b1b` (the original rebrand commit)

## Correct Hook Disable Checklist for Safe Upgrade

```bash
# Disable ALL Guardian hooks before rebase
cd /mnt/c/Users/thadd/hermes-web-ui
mv .git/hooks/post-checkout .git/hooks/post-checkout.bak
mv .git/hooks/post-merge   .git/hooks/post-merge.bak
mv .git/hooks/post-rewrite .git/hooks/post-rewrite.bak

# ... perform rebase ...

# Re-enable ALL after rebase completes
cd /mnt/c/Users/thadd/hermes-web-ui
mv .git/hooks/post-checkout.bak .git/hooks/post-checkout
mv .git/hooks/post-merge.bak   .git/hooks/post-merge
mv .git/hooks/post-rewrite.bak .git/hooks/post-rewrite
chmod +x .git/hooks/post-checkout .git/hooks/post-merge .git/hooks/post-rewrite
```

## Post-Rebase `git status` Check
After rebase, run:
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
git status --short
```

Expected: **empty output** (nothing staged, nothing modified).

If any Spock-customized file appears as modified (e.g., `M  AppSidebar.vue`), investigate immediately. Most likely a stale Guardian hook mis-applied a backup. Use `git checkout HEAD -- <file>` to reset to the rebased HEAD version, then manually re-apply only the Spock-specific text if the generic backup overwrote it.

## Build Dependency Gap
After rebasing to v0.6.0, the package `@vscode/markdown-it-katex` was referenced in `package.json` but not in `node_modules`. Build failed with:
```
Cannot find module '@vscode/markdown-it-katex' or its corresponding type declarations.
```
Fix: `npm install @vscode/markdown-it-katex --save` before `npm run build`.

## Asset Verification After v0.6.0 Build
Newer Vite/rolldown builds produce hashed asset filenames (e.g., `thinking-light-B_T3hcgV.mp4`). The dist tree has a hashed copy AND a plain copy. Server serves from hashed paths. Spock verification check looks for the plain copy in `dist/client/assets/mp4/`.

Commands used:
```bash
# Find hashed thinking videos
find dist/client/assets/mp4 -name "*thinking*"

# Ensure plain-named copies also exist for safety and verification
cp packages/client/src/assets/thinking-dark.mp4 dist/client/assets/mp4/
cp packages/client/src/assets/thinking-light.mp4 dist/client/assets/mp4/
```

## Lesson: Hook Superset Must Be Disabled
The safe-upgrade workflow in spock-webui-upgrade-preservation previously only listed `post-checkout` and `post-merge`. It MUST also disable `post-rewrite` — this hook fires during `git pull --rebase` and is the most dangerous because it fires on every rewritten commit.
