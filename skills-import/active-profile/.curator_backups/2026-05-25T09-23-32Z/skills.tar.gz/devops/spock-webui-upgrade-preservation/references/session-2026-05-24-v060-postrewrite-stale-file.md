# v0.6.0 Upgrade — Post-Rewrite Hook Stale File Incident

**Date:** 2026-05-24
**Session:** hermes-web-ui upgrade from pre-v0.6.0 to v0.6.0
**Profile:** devteam

---

## Incident Summary

During `git pull --rebase` from origin/main (v0.6.0), the `.git/hooks/post-rewrite` Guardian hook fired on every rewritten commit and overwrote `AppSidebar.vue` with a stale version from commit `6146e90`. This removed upstream features added between `6146e90` and `HEAD`, specifically:

- `isSuperAdmin` computed import and guard
- `performance` menu item (conditional on `isSuperAdmin`)
- `profile` route guard (conditional on `isSuperAdmin`)
- Correct `selectedKey` mapping (special routes mapped to parent keys)
- Correct `skillsUsage` SVG icon (pie chart, not trend chart)

The hook was hardcoded to use `git checkout 6146e90 -- <file>`, which always restores the exact state from that historical commit — obliterating any upstream additions made after it.

---

## Root Cause

```bash
# The old hook logic (simplified):
SPOCK_COMMIT="6146e90"
for file in "${PROTECTED_FILES}"; do
  git checkout "$SPOCK_COMMIT" -- "$file"  # ← restores stale version
```

This was the `post-rewrite` hook inside `.git/hooks/post-rewrite`. Each time git rewrote a commit during rebase, the hook ran and reverted the file to commit `6146e90`'s version, regardless of what the rebased HEAD contained.

Crucially, the hook had **no rebase-in-progress guard**, so it fired during the rebase itself (not after it finished), corrupting intermediate states.

---

## Detection

After `git pull --rebase` completed successfully, `git status --short` showed:

```
M  packages/client/src/components/layout/AppSidebar.vue
```

The diff showed:
- Minus: `import { isStoredSuperAdmin } from '@/api/client';`, `isSuperAdmin` computed, route mapping logic
- Plus: Simple `selectedKey = () => route.name`, removed performance button, changed `skillsUsage` icon to wrong SVG
- Spock text ("Spock" sidebar label, `/logo.png`) was still present — the file wasn't fully reverted, just partially overwritten by a version that had Spock branding but fewer upstream features

This revealed the hook restored a version from an **intermediate** Spock commit, not the current rebased HEAD.

---

## Fix Procedure

1. **Check current hooked files:**
   ```bash
   ls /mnt/c/Users/thadd/hermes-web-ui/.git/hooks/post-*
   ```
   Found `post-checkout`, `post-merge`, `post-rewrite` (the rebase-specific one).

2. **Verify HEAD version:**
   ```bash
   git show HEAD:packages/client/src/components/layout/AppSidebar.vue > /tmp/head-sidebar.vue
   grep -n "isSuperAdmin\|performance\|skillsUsage\|logoPath" /tmp/head-sidebar.vue
   # Confirmed HEAD had the upstream features + Spock branding
   ```

3. **Reset working file to HEAD:**
   ```bash
   git checkout HEAD -- packages/client/src/components/layout/AppSidebar.vue
   ```

4. **Disable old hook:**
   ```bash
   mv .git/hooks/post-rewrite .git/hooks/post-rewrite.bak
   ```

5. **Rewrite the hook:**
   - Skip during active rebase (check `rebase-merge/HEAD`)
   - Use file backups from `~/.hermes/spock-protector/` instead of `git checkout <commit> --`
   - Fall back to `git checkout HEAD -- <file>` if backup missing
   - Never use a hardcoded historical commit hash

6. **Verify clean state:**
   ```bash
   git status --short
   # Empty output = clean working tree
   ```

---

## Correct Hook (post-rewrite.sh)

```bash
#!/bin/bash
# Spock Guardian — auto-restore customizations after rebase/rewrite

# SKIP during active rebase to avoid creating unstaged changes
if [ -f "$(git rev-parse --git-path rebase-merge/HEAD)" ] || \
   git rev-parse --verify MERGE_HEAD >/dev/null 2>&1; then
  exit 0
fi

REPO_ROOT="$(git rev-parse --show-toplevel)"
BACKUP="/home/thadd/.hermes/spock-protector"

PROTECTED_FILES=(
  "packages/client/public/spock-avatar.png"
  "packages/client/public/favicon.ico"
  "packages/client/public/favicon.png"
  "packages/client/index.html"
  "packages/client/public/logo.png"
  "packages/client/src/assets/logo.png"
  "packages/client/src/assets/thinking-dark.mp4"
  "packages/client/src/assets/thinking-light.mp4"
  "packages/client/src/components/layout/AppSidebar.vue"
  "packages/client/src/components/hermes/chat/SessionListItem.vue"
  "packages/client/src/components/hermes/profiles/ProfileAvatar.vue"
  "vite.config.website.ts"
)

RESTORED=0
for file in "${PROTECTED_FILES[@]}"; do
  # Prefer file backup — never restores stale version
  if [ -f "$BACKUP/$file" ]; then
    if ! diff -q "$BACKUP/$file" "$REPO_ROOT/$file" >/dev/null 2>&1; then
      cp "$BACKUP/$file" "$REPO_ROOT/$file"
      RESTORED=1
    fi
  # Fallback: restore from HEAD (current rebased state), never hardcoded commit
  elif ! git diff --quiet HEAD -- "$REPO_ROOT/$file" 2>/dev/null; then
    git checkout HEAD -- "$REPO_ROOT/$file"
    RESTORED=1
  fi
done

if [ "$RESTORED" -eq 1 ]; then
  echo "[Spock Guardian] Spock customizations restored."
fi
```

Key principle: **HEAD is the source of truth for what's current**. The backup is what Spock should look like. Using a hardcoded historical commit destroys everything upstream added after that point.

---

## Verification After Upgrade

All Spock customizations present AND upstream features intact:

```
✓ packages/client/src/components/hermes/profiles/ProfileAvatar.vue  (spock-avatar.png)
✓ packages/client/src/components/hermes/chat/SessionListItem.vue     (spock-avatar.png)
✓ packages/client/src/components/layout/AppSidebar.vue               (Spock branding + isSuperAdmin + performance menu)
✓ packages/client/index.html                                        (Spock title)
✓ packages/client/public/logo.png                                   (Spock logo)
✓ packages/client/public/spock-avatar.png                           (avatar asset)
✓ packages/client/public/favicon.ico                                (multi-res Spock ICO)
✓ dist/client/spock-avatar.png                                      (compiled)
✓ dist/client/favicon.ico                                           (compiled)
✓ dist/client/logo.png                                              (compiled)
✓ dist/client/assets/mp4/thinking-dark.mp4                          (thinking video)
✓ dist/client/assets/mp4/thinking-light.mp4                         (thinking video)
```

Upstream v0.6.0 features confirmed working:
- Profile-scoped skills, memory, kanban, channels, plugins
- LaTeX/KaTeX rendering in chat
- Inline file preview for text files
- Bridge performance monitoring

---

## Lessons

1. **Disable ALL hooks before rebase**, not just `post-checkout` and `post-merge`. `post-rewrite` is the third one and arguably the most dangerous during rebase.
2. **Never use a hardcoded commit hash in recovery logic.** It guarantees staleness over time. Use `HEAD` for live-checkout or file backups for authoritative restore.
3. **After rebase, run `git status --short`** immediately. Any unstaged modifications in Spock-customized files mean a hook fired during rebase and corrupted the rebase.
4. **Check the diff carefully.** The diff showed Spock text was still present but upstream features were gone. This means a stale intermediate version was restored, not a full revert.
5. **Rebuild and restart after every upgrade.** Don't assume git state is sufficient — `dist/` holds compiled assets that must match the source.
