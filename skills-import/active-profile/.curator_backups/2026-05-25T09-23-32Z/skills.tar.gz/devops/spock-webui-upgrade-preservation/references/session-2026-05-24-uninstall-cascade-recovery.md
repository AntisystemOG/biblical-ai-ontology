# Session 2026-05-24 — OpenClaw Uninstall Cascade Failure

## What Happened

The user ran `openclaw uninstall` which deleted the workspace at `/mnt/c/Users/thadd/.openclaw/workspace/` AND partially cleaned `~/.hermes/`, destroying the `spock-protector/` backup directory. This created a cascade of silent regressions detected later as "icons messed up again."

## The Cascade Chain

| Step | What Broke | Why It Was Silent |
|------|-----------|-------------------|
| 1 | OpenClaw workspace deleted | `/mnt/c/Users/thadd/.openclaw/workspace/` gone. Spock's memory corpus, agents, daily notes gone. |
| 2 | `~/.hermes/spock-protector/` deleted | Immutable backup of all 11 protected files wiped. |
| 3 | `favicon.ico` was the **wrong file** in git | Commit `5c0bd0b` (Spock branding) kept the old 16,958 byte default EKKO icon. The real Spock multi-res ICO was only in spock-protector, now gone. |
| 4 | Git operations restored wrong icon | Any checkout, build, or npm operation pulled the old default from git history. |
| 5 | User sees "icons are messed up" | Browser tab shows old default EKKO icon, not Spock. |
| 6 | Memory workspace was previously migrated to `.local/.openclaw/` | SOUL.md, USER.md, etc. found there. But WebUI icon issue was real. |

## Root Cause: Spock favicon Was Never in Git

Commit `5c0bd0b` added `favicon.png` (Spock PNG) but **did NOT** replace `favicon.ico` with a Spock-built multi-resolution ICO. The file remained the original EKKO default (16,958 bytes, single 64x64). The correct ICO (123,546 bytes, 6 resolutions) was only in spock-protector, which OpenClaw's uninstall wiped.

**SHA256s:**
- EKKO default: `2a0313824bd62299f4c70e83908c2a524175dd20645022a3ecfb940c6e5aeba3`
- Spock multi-res: `42faff213dcc7802b89687433066d9564a270fd7a197322535ed62b811dc6c83`

## Recovery Steps Applied

1. **Rebuilt favicon.ico** from `spock-avatar.png` using Pillow (Hermes venv Python):
   - Square-cropped (721x721 center crop)
   - 6 resolutions: 16, 32, 48, 64, 128, 256 px
   - 123,546 bytes total
   - Copied to `dist/client/favicon.ico`

2. **Rebuilt spock-protector/** with correct mirrored `packages/client/` structure.

3. **Copied missing thinking videos** to `dist/client/assets/` — missing from dist, would cause thinking-animation failure.

4. **Committed and pushed** fix as `b8d1c21` to `AntisystemOG/hermes-web-ui`.

5. **Updated skills** with CRITICAL SAFEGUARD sections.

## Verification — Run After Any Install/Uninstall/Migration

```bash
# favicon must be multi-res Spock ICO
file /mnt/c/Users/thadd/hermes-web-ui/packages/client/public/favicon.ico | grep "6 icons"
sha256sum /mnt/c/Users/thadd/hermes-web-ui/packages/client/public/favicon.ico | grep "42faff21"

# dist must be complete
curl -sf http://localhost:8648/favicon.ico -o /tmp/favicon-test.ico
file /tmp/favicon-test.ico | grep "6 icons"
ls /mnt/c/Users/thadd/hermes-web-ui/dist/client/assets/thinking-dark.mp4
ls /mnt/c/Users/thadd/hermes-web-ui/dist/client/assets/thinking-light.mp4

# protector structure must exist
find ~/.hermes/spock-protector/packages/client -type f | wc -l  # >= 10
```

## Key Lesson

Never trust a backup in a directory an installer can delete. Future improvements:
1. Second backup outside `~/.hermes/` (e.g., `Documents/SpockProtector/`)
2. Git-commit binary assets so they survive filesystem deletion
3. Post-uninstall verification script (see `scripts/verify-spock-branding.sh`)
