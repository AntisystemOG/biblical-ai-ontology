---
title: Spock WebUI Upgrade with Customization Preservation
name: spock-webui-upgrade-preservation
trigger: |
  Any task involving upgrading, updating, pulling upstream changes, or syncing
  the EKKOLearnAI / hermes-web-ui repository when Spock customizations (branding,
  avatar, sidebar, title, logo) are present. Also applies to rebasing, merging
  origin/main, or running `git pull` in the hermes-web-ui repo.
description: |
  The Spock WebUI at /mnt/c/Users/thadd/hermes-web-ui carries persistent
  customizations (Spock rebrand, avatar image, sidebar text, browser title).
  Upgrades must NEVER overwrite, drop, or conflict these customizations.
  This skill documents the safe upgrade workflow, the guardian hook, and
  forbidden actions.
---

# Spock WebUI Upgrade — Customization Preservation Rule

## Core Rule

**NEVER upgrade in a way that changes or discards Spock customizations.**

Customizations are authoritative. The upstream EKKOLearnAI repo is secondary.
When upgrading, merge or rebase **in favor of the local Spock customizations**,
not the upstream defaults.

### Emergency Recovery

If customizations are lost during an upgrade:
1. **Restore from local backup:** `C:\Users\thadd\Documents\SpockWebUI` contains a complete backup of the working WebUI with all customizations
2. **Re-apply from git reflog:** `git reset --hard HEAD@{1}` (if caught immediately)
3. **Re-apply from upstream merge:** See `hermes-webui-spock` skill for the 3-layer Spock Protector system

Always verify the backup exists before attempting risky upgrade operations.

## What Constitutes Spock Customizations

| File | Customization |
|------|--------------|
| `packages/client/public/spock-avatar.png` | Spock avatar image (replaces multiavatar) |
| `packages/client/public/favicon.ico` | Browser tab icon (multi-res Spock ICO) |
| `packages/client/public/favicon.png` | Browser tab icon (PNG backup) |
| `packages/client/src/components/hermes/profiles/ProfileAvatar.vue` | **UNIVERSAL AVATAR** — ALL profile avatars render as Spock image instead of multiavatar SVG |
| `packages/client/src/components/hermes/chat/SessionListItem.vue` | Session list passes Spock image object to ProfileAvatar |
| `packages/client/src/components/layout/AppSidebar.vue` | Spock sidebar branding / title |
| `packages/client/public/logo.png` | Spock/EKKOLearnAI logo |
| `packages/client/index.html` | Browser title / favicon |
| `packages/client/src/assets/logo.png` | Logo asset |
| `packages/client/src/assets/thinking-dark.mp4` | Spock thinking animation |
| `packages/client/src/assets/thinking-light.mp4` | Spock thinking animation |
| `vite.config.website.ts` | Website build customization |
| `dist/client/spock-avatar.png` | Compiled avatar asset |
| `dist/client/favicon.ico` | Compiled tab icon |
| `dist/client/assets/js/OutlinePanel-*.js` | Compiled JS with Spock avatar patches |
| `dist/client/assets/js/index-*.js` | Compiled JS with ProfileAvatar universal Spock |
| Any `.git/hooks/post-checkout` or `post-merge` guardian hook | Spock Guardian restoration hook |

## Safe Upgrade Workflow

### 1. Check Current State
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
git status --short
git log --oneline -5
```

If there are unstaged changes, **do NOT proceed** until they are resolved.

### 2. Verify Spock Base Commits Exist

The two commits that contain all Spock customizations must exist in git history
before starting:
- `f636b1b` — Original rebrand (logo, title, sidebar, thinking videos)
- `9caac49` — Spock avatar for session list (or latest avatar commit)

```bash
cd /mnt/c/Users/thadd/hermes-web-ui
for commit in f636b1b 9caac49; do
  git cat-file -t "$commit" >/dev/null 2>&1 && echo "✓ $commit exists" || echo "✗ $commit MISSING"
done
```

If either is missing, abort the upgrade and restore from backup first.

### 3. Stash or Commit Pre-existing Changes
If the working tree has local modifications unrelated to the upgrade:
```bash
git stash push -m "pre-upgrade local changes" --include-untracked
```

### 3. Fetch Upstream (Never Pull Directly)
```bash
git fetch origin
```

### 4. Temporarily Disable All Guardian Hooks (CRITICAL — All Three)
The Spock Guardian hooks (`post-checkout`, `post-merge`, `post-rewrite`) auto-restore
files after any checkout or rewrite. During a rebase, the `post-rewrite` hook fires
on **every rewritten commit**, creating unstaged modifications that abort the rebase:
```
error: cannot rebase: You have unstaged changes.
```
Worse, it may restore a **stale** version of a file (if the protector backup is from
an older commit), overwriting upstream features that were added since the backup
was created.

**Disable ALL THREE before rebase:**
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
mv .git/hooks/post-checkout .git/hooks/post-checkout.bak 2>/dev/null || true
mv .git/hooks/post-merge   .git/hooks/post-merge.bak   2>/dev/null || true
mv .git/hooks/post-rewrite .git/hooks/post-rewrite.bak 2>/dev/null || true
```

**After rebase, re-enable all three:**
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
mv .git/hooks/post-checkout.bak .git/hooks/post-checkout 2>/dev/null || true
mv .git/hooks/post-merge.bak   .git/hooks/post-merge   2>/dev/null || true
mv .git/hooks/post-rewrite.bak .git/hooks/post-rewrite 2>/dev/null || true
chmod +x .git/hooks/post-checkout .git/hooks/post-merge .git/hooks/post-rewrite
```

### 5. Rebase onto Upstream (Preserve Spock)
```bash
git config pull.rebase true
git pull origin main
```

If conflicts occur in Spock-customized files:
- **ALWAYS resolve in favor of the local (Spock) version**
- Mark resolved: `git add <file>`
- Continue: `git rebase --continue`

### 5a. Re-enable Guardian Hooks
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
mv .git/hooks/post-checkout.bak .git/hooks/post-checkout 2>/dev/null || true
mv .git/hooks/post-merge.bak   .git/hooks/post-merge   2>/dev/null || true
mv .git/hooks/post-rewrite.bak .git/hooks/post-rewrite 2>/dev/null || true
chmod +x .git/hooks/post-checkout .git/hooks/post-merge .git/hooks/post-rewrite
```

### 5b. Post-Rebase Staging Cleanup (if needed)
If the Guardian hook fired during rebase before you could disable it, or if
upstream changed a Spock-customized file's CSS/layout (e.g., `AppSidebar.vue`
gap/flex properties), the file may have staged upstream changes mixed with
Spock text.

**Reset the file to the rebased Spock version and re-stage cleanly:**
```bash
git checkout HEAD -- packages/client/src/components/layout/AppSidebar.vue
git add packages/client/src/components/layout/AppSidebar.vue
```

Then verify with `git status --short` that only real Spock changes are staged.

### 6. Verify Customizations Intact
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
echo "=== Checking Spock customizations ==="
grep -q "spock-avatar.png" packages/client/src/components/hermes/profiles/ProfileAvatar.vue && echo "✓ Universal avatar OK"
grep -q "spock-avatar.png" packages/client/src/components/hermes/chat/SessionListItem.vue && echo "✓ SessionListItem avatar OK"
grep -q "spock" packages/client/src/components/layout/AppSidebar.vue && echo "✓ Sidebar OK"
grep -q "Spock" packages/client/index.html && echo "✓ Title OK"
ls packages/client/public/spock-avatar.png && echo "✓ Avatar asset OK"
ls packages/client/public/favicon.ico && echo "✓ favicon.ico asset OK"
ls dist/client/spock-avatar.png && echo "✓ Dist avatar OK"
ls dist/client/favicon.ico && echo "✓ Dist favicon OK"
grep -q "spock-avatar" dist/client/assets/js/OutlinePanel-*.js 2>/dev/null && echo "✓ Dist JS OK"
```

### 7. Push to Spock Fork

After a successful rebase, the local commit hashes change. Push to the fork
with force to overwrite the old branch:

```bash
cd /mnt/c/Users/thadd/hermes-web-ui
git push spock main --force-with-lease
```

If `--force-with-lease` rejects (remote has new commits), inspect first:
```bash
git fetch spock
git log spock/main..HEAD --oneline   # what would be overwritten
git push spock main --force           # only if confirmed safe
### 8. Rebuild Dist (if build system works)
```bash
# Only if build is functional; if rolldown is broken, skip and patch dist manually
cd /mnt/c/Users/thadd/hermes-web-ui && npm run build 2>/dev/null || echo "Build broken — patch dist/ manually"
```

If build is broken, manually propagate source changes to `dist/client/` compiled JS.
See `references/session-2026-05-22-avatar-dist-patching.md` in the
`hermes-webui-spock` skill for the exact dist-JS patch technique.

### 9. Restart Server
```bash
# Kill existing
cd /mnt/c/Users/thadd/hermes-web-ui && pkill -f "node dist/server/index.js" || true
# Restart via launcher or manually
bash -lic "cd /mnt/c/Users/thadd/hermes-web-ui && node dist/server/index.js" &
```

## Forbidden Actions (Never Do These)

| Action | Why Forbidden |
|--------|--------------|
| `git reset --hard origin/main` | Wipes all Spock customizations instantly |
| `git checkout origin/main -- .` | Overwrites all local files with upstream defaults |
| `git merge origin/main` without reviewing | May silently prefer upstream over Spock customizations |
| `git pull` without rebasing strategy | Creates merge commits that can override customizations |
| Deleting `dist/` and rebuilding from clean upstream | Loses compiled-in Spock patches |
| Running `git clean -fd` | Deletes untracked assets like `spock-avatar.png` |

## The Spock Guardian Hook

There is a git hook (`post-checkout` / `post-merge`) that auto-restores some
Spock files after checkout. **Do not rely solely on it** — it may fail or
restore incomplete state. Always verify manually after any upgrade operation.

## If Customizations Are Lost

1. Abort immediately: `git reset --hard HEAD@{1}` (if recent)
2. Check reflog: `git reflog --all | head -20`
3. Restore from backup if available (old build at `~/hermes-web-ui-ekko/`)
4. Re-apply customizations from memory / this skill

## Pitfall: OpenClaw Uninstall Deletes Workspace, User Conflates with Icon Bug

**Symptom:** User reports "icons are messed up again" after running an OpenClaw uninstall command.

**Actual cause:** The uninstall command (`openclaw uninstall`) deleted the entire workspace at `/mnt/c/Users/thadd/.openclaw/workspace/`. The user conflated the missing workspace with the WebUI icons being wrong. The WebUI branding was actually intact; the browser may just need a hard-refresh.

**Detection:**
```bash
ls -d /mnt/c/Users/thadd/.openclaw/workspace/ 2>/dev/null || echo "WORKSPACE MISSING"
```

**Fix:** Restore workspace from the migration backup:
```bash
mkdir -p /mnt/c/Users/thadd/.openclaw/workspace
cp -r /home/thad/.hermes/webui/openclaw-migrated/* /mnt/c/Users/thadd/.openclaw/workspace/
```

The backup at `/home/thad/.hermes/webui/openclaw-migrated/` contains a full copy from the initial migration and should always be preserved.

**Then check actual WebUI branding:**
```bash
curl -sf http://localhost:8648/logo.png -I | grep Content-Length      # ~726468
curl -sf http://localhost:8648/spock-avatar.png -I | grep Content-Length # ~726468
```

If the assets are correct, tell the user to hard-refresh their browser (`Ctrl+Shift+R` or `Ctrl+F5`). The "icon bug" is usually browser cache, not a real regression.

## Pitfall: Post-Rewrite Hook Restores Stale File During Rebase

**Symptom:** After rebase completes, `git status` shows modified
`AppSidebar.vue`, `SessionListItem.vue`, or `ProfileAvatar.vue`. The diff
removes upstream features (`isSuperAdmin`, `performance` menu, `profile` route
guard, etc.) that were added in the new upstream version.

**Root cause:** The `.git/hooks/post-rewrite` hook fires on every rewritten
commit during `git pull --rebase`. It checked a stale commit hash
(`6146e90` — pre-v0.6.0) and ran `git checkout 6146e90 -- <file>`, which
overwrote the newly-rebased file with the old version, discarding upstream
additions.

**Fix:**
```bash
# Step 1: Reset to the rebased HEAD version (preserves Spock + upstream)
git checkout HEAD -- packages/client/src/components/layout/AppSidebar.vue
git checkout HEAD -- packages/client/src/components/hermes/chat/SessionListItem.vue
git checkout HEAD -- packages/client/src/components/hermes/profiles/ProfileAvatar.vue

# Step 2: Verify git status is clean
git status --short
```

**Prevention (hook rewrite):**
The `post-rewrite` hook must:
1. **Skip during active rebase** by checking `$(git rev-parse --git-path rebase-merge/HEAD)`
2. Use the **file backup** from `~/.hermes/spock-protector/` instead of `git checkout <commit> -- <file>`
3. Fall back to `git checkout HEAD -- <file>` (not a hardcoded commit) if backup is missing

See rewritten hook at `~/.hermes/scripts/verify-spock-branding.sh`.

## Pitfall: Post-Checkout Hook Leaves Unstaged Changes That Revert Branding

**Symptom:** After `git checkout` or `git reset`, `git status` shows modified `SessionListItem.vue` or `ProfileAvatar.vue` that would revert Spock branding back to multiavatar.

**Root cause:** The Spock Protector post-checkout hook fires after every checkout, copying backup files into the working tree. If the backup was captured at a commit that differs from HEAD (e.g., after an npm update/downgrade), the hook re-applies a slightly different version than what HEAD contains, creating unstaged diffs.

**Fix:** Use `git reset HEAD -- <file>` to unstage, then let the hook re-fire or manually verify the file is correct after the hook runs.

```bash
git reset HEAD -- packages/client/src/components/hermes/chat/SessionListItem.vue
git reset HEAD -- packages/client/src/components/hermes/profiles/ProfileAvatar.vue
git reset HEAD -- package.json
```

**Prevention:** After any git operation that touches Spock files, run `git status --short` immediately. If unstaged Spock-file modifications appear and their diff shows reversion to multiavatar, the hook mis-applied a stale backup. Restore from the `~/.hermes/spock-protector` backup instead.

**See also:** `references/session-2026-05-23-icons-messed-up-diagnostic.md` — full diagnostic workflow for "icons messed up" reports.

## Pitfall: Stale dist/ Build After Source Fix

**Symptom:** Source files (`SessionListItem.vue`) are correct and show the Spock avatar code, but the browser still shows the old anime multiavatar character.
```bash
# Check when dist/ was last modified
ls -la dist/client/index.html   # timestamp reveals build age
# Compare to git log
git log --oneline -3
```
If the dist timestamp predates the avatar fix commit, it's stale.

**Fix:** Rebuild with `npm run build` (if build works) or restore server from backup:
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
npm run build
# If build times out and wipes dist/server/ (see below), restore server from backup:
rsync -avh /mnt/c/Users/thadd/Documents/SpockWebUI/dist/server/ dist/server/
```
Then restart the systemd service.

## Pitfall: Build Timeout Wipes dist/server/

**Symptom:** After `npm run build` times out, the server fails to start with:
```
Error: Cannot find module '/mnt/c/Users/thadd/hermes-web-ui/dist/server/index.js'
```

**Root cause:** The build process cleans `dist/` at the start. If it times out during the server compilation phase, `dist/server/` remains empty while `dist/client/` may be partially or fully intact.

**Fix — restore server from backup:**
```bash
rsync -avh /mnt/c/Users/thadd/Documents/SpockWebUI/dist/server/ /mnt/c/Users/thadd/hermes-web-ui/dist/server/
```
The `Documents/SpockWebUI` backup always contains a working `dist/server/` from the last successful build.

## CRITICAL SAFEGUARD: favicon.ico is Always Spock Multi-Resolution ICO

**Rule:** The file `packages/client/public/favicon.ico` must ALWAYS be a proper multi-resolution Windows ICO built from `spock-avatar.png`. It must NEVER be the old default EKKO icon (16,958 bytes, single 64x64 image) or any other non-Spock asset.

**Detection (automated):**
```bash
# Bad icon: single icon, ~16KB, old EKKO default
# Good icon: 6 icons, ~120KB, built from Spock image
file /mnt/c/Users/thadd/hermes-web-ui/packages/client/public/favicon.ico
# Expected output: "MS Windows icon resource - 6 icons, 16x16 ... 32x32 ..."

# SHA256 verification (post 2026-05-24 build)
sha256sum /mnt/c/Users/thadd/hermes-web-ui/packages/client/public/favicon.ico
# Expected: 42faff213dcc7802b89687433066d9564a270fd7a197322535ed62b811dc6c83
```

**Rebuild (when wrong icon detected):**
```bash
/home/thadd/.hermes/hermes-agent/venv/bin/python -c "
from PIL import Image
import shutil
src = '/mnt/c/Users/thadd/hermes-web-ui/packages/client/public/spock-avatar.png'
dst_public = '/mnt/c/Users/thadd/hermes-web-ui/packages/client/public/favicon.ico'
dst_dist = '/mnt/c/Users/thadd/hermes-web-ui/dist/client/favicon.ico'
img = Image.open(src)
if img.mode != 'RGBA': img = img.convert('RGBA')
w, h = img.size; min_dim = min(w, h)
square = img.crop(((w-min_dim)//2, (h-min_dim)//2, (w+min_dim)//2, (h+min_dim)//2))
sizes = [(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)]
square.save(dst_public, format='ICO', sizes=sizes)
shutil.copy2(dst_public, dst_dist)
print('favicon.ico rebuilt:', dst_public, '->', os.path.getsize(dst_public), 'bytes')
"
```

**Dist copy required:** After rebuilding `public/favicon.ico`, always copy to `dist/client/favicon.ico`. The server serves from `dist/`.

**spock-protector backup update:** After rebuilding, copy the new ICO into the protector backup tree so `restore-spock.sh` produces correct files:
```bash
cp /mnt/c/Users/thadd/hermes-web-ui/packages/client/public/favicon.ico \
   /home/thadd/.hermes/spock-protector/packages/client/public/favicon.ico
```

## CRITICAL SAFEGUARD: spock-protector Backup Structure

**Rule:** The `~/.hermes/spock-protector/` directory must mirror the repo's `packages/client/` structure. `restore-spock.sh` expects this layout. Assets dumped at the root level will NOT be restored correctly.

**Required structure:**
```
~/.hermes/spock-protector/
  packages/client/public/favicon.ico       ← multi-res Spock ICO
  packages/client/public/favicon.png        ← Spock PNG backup
  packages/client/public/logo.png           ← Spock logo
  packages/client/public/spock-avatar.png   ← Spock avatar
  packages/client/src/assets/logo.png       ← Sidebar logo
  packages/client/src/assets/thinking-dark.mp4   ← Thinking video
  packages/client/src/assets/thinking-light.mp4  ← Thinking video
  packages/client/src/components/layout/AppSidebar.vue        ← Sidebar text
  packages/client/src/components/hermes/chat/SessionListItem.vue   ← Avatar image obj
  packages/client/src/components/hermes/profiles/ProfileAvatar.vue ← Universal avatar
  packages/client/index.html                ← Title + favicon ref
  vite.config.website.ts                  ← Build config
  restore-spock.sh                      ← Hard restore script
  PROTECTED_FILES.txt                    ← Registry
```

**Root-level file cleanup:** After copying new assets into `packages/client/...`, remove root-level duplicates to prevent confusion:
```bash
rm -f ~/.hermes/spock-protector/favicon.ico ~/.hermes/spock-protector/favicon.png \
      ~/.hermes/spock-protector/logo.png ~/.hermes/spock-protector/spock-avatar.png \
      ~/.hermes/spock-protector/ProfileAvatar.vue
```

**Verification:**
```bash
find ~/.hermes/spock-protector/ -type f | grep -c "packages/client"
# Should return ≥ 11 (all protected source files)
```

## CRITICAL SAFEGUARD: Dist Completeness — thinking Videos Must Exist

**Rule:** The `dist/client/assets/` directory must contain `thinking-dark.mp4` and `thinking-light.mp4`. These are NOT auto-copied by the build if the build system is broken (rolldown), causing the "thinking" animation to fail.

**Detection:**
```bash
ls /mnt/c/Users/thadd/hermes-web-ui/dist/client/assets/thinking-dark.mp4 2>/dev/null || echo "MISSING"
ls /mnt/c/Users/thadd/hermes-web-ui/dist/client/assets/thinking-light.mp4 2>/dev/null || echo "MISSING"
```

**Fix (manual copy when build is broken):**
```bash
cp /mnt/c/Users/thadd/hermes-web-ui/packages/client/src/assets/thinking-dark.mp4 \
   /mnt/c/Users/thadd/hermes-web-ui/dist/client/assets/
cp /mnt/c/Users/thadd/hermes-web-ui/packages/client/src/assets/thinking-light.mp4 \
   /mnt/c/Users/thadd/hermes-web-ui/dist/client/assets/
```

## Pitfall: favicon.ico vs favicon.png Mismatch

**Symptom:** Browser tab shows old default icon instead of Spock.

**Root cause:** `packages/client/index.html` references `/favicon.ico`, but `packages/client/public/favicon.ico` is the old default icon (dated before the rebrand). The Spock image was added as `favicon.png` but the HTML still points to `.ico`.

**Fix:** See "CRITICAL SAFEGUARD: favicon.ico is Always Spock Multi-Resolution ICO" above. The fix is identical — rebuild ICO from `spock-avatar.png`.

**Protection:** Add `favicon.ico` to the Spock Protector registry (`PROTECTED_FILES.txt` and `restore-spock.sh`) so upgrades do not overwrite it.

## Verification Checklist Post-Upgrade

- [ ] `spock-avatar.png` exists in `packages/client/public/`
- [ ] `spock-avatar.png` exists in `dist/client/`
- [ ] `favicon.ico` exists in `packages/client/public/` and `dist/client/` (Spock multi-res ICO, not old default)
- [ ] `SessionListItem.vue` references `/spock-avatar.png` as `{type:'image',dataUrl:'/spock-avatar.png'}` (NOT a plain string)
- [ ] `AppSidebar.vue` retains Spock branding
- [ ] `logo.png` and `index.html` are correct
- [ ] `dist/client/assets/js/OutlinePanel-*.js` contain Spock patches (if build broken)
- [ ] dist/ build timestamp is newer than the latest Spock commit (not stale)
- [ ] `dist/server/index.js` exists and is non-empty
- [ ] WebUI loads and shows Spock avatar in session list
- [ ] Browser tab title shows Spock branding
- [ ] Browser tab icon shows Spock (not old default)
- [ ] Local backup `C:\Users\thadd\Documents\SpockWebUI` is up to date (run backup after successful upgrade)
- [ ] Spock Guardian hooks (`post-checkout`, `post-merge`) are enabled in `.git/hooks/`
- [ ] Fork (`spock` remote) pushed with rebased commits

## CRITICAL: Auth State and Database Path Awareness

### The `AUTH_DISABLED` Environment Variable

The WebUI auth system is controlled by `AUTH_DISABLED`:
- `AUTH_DISABLED=1` or `true` → **All auth disabled**. `getToken()` returns `null`. The login endpoint rejects with `{"error":"Auth is disabled on this server"}`. SPA auto-login skips. Bearer tokens are not required for API access.
- `AUTH_DISABLED` unset or empty → **Auth active**. The server generates/reads a bearer token from `~/.hermes-web-ui/.token` and enforces it on API routes. Username/password login is available if a user exists in the DB.

**Sources of `AUTH_DISABLED` (checked in order of precedence):**
1. `~/.hermes/.env` — Hermes master environment file (line `AUTH_DISABLED=1`)
2. `~/.hermes/webui/start-server.sh` — Launcher script that sources `.env` then **overrides** with `export AUTH_DISABLED=1`
3. Parent process environment (e.g., systemd unit, `hermes` CLI, or your shell)

**To enable username/password login after upgrade:**
```bash
# 1. Remove or comment out in master .env
sed -i 's/^AUTH_DISABLED=1/# AUTH_DISABLED=1/' ~/.hermes/.env

# 2. Remove override in launcher script
sed -i 's/^export AUTH_DISABLED=1/# export AUTH_DISABLED=1/' ~/.hermes/webui/start-server.sh

# 3. Restart server WITHOUT the variable
env -u AUTH_DISABLED bash -lic 'cd /mnt/c/Users/thadd/hermes-web-ui && node dist/server/index.js'
```

**Verification:**
```bash
curl -sf http://localhost:8648/api/auth/status
# Expected: {"hasPasswordLogin":true,"username":"...","hasUsers":true|false}
```
If `hasUsers` is `false`, no account exists yet — the next login attempt will auto-bootstrap a super_admin.

### Database Path: Dev vs. Production

The SQLite DB location depends on `NODE_ENV`:
- **Development** (`NODE_ENV=development` or unset): `packages/server/data/hermes-web-ui.db`
- **Production** (`NODE_ENV=production`): `~/.hermes-web-ui/hermes-web-ui.db`

**Risk:** If you previously ran in production mode and upgrade while running in dev mode (or vice versa), the `users` table will appear empty because the server is reading a different DB file. The legacy DB at `~/.hermes-web-ui/hermes-web-ui.db` may also lack the `users` table entirely if it predates the username/password feature.

**Detection:**
```bash
# Check both paths
for db in packages/server/data/hermes-web-ui.db ~/.hermes-web-ui/hermes-web-ui.db; do
  echo "=== $db ==="
  sqlite3 "$db" "SELECT COUNT(*) FROM users;" 2>/dev/null || echo "No users table"
done
```

**Fix if account is in the wrong DB:**
1. Export the user row from the old DB (if it has one)
2. Insert into the new DB with the same `password_hash` so the password remains valid
3. Or simply recreate the account via the WebUI login flow (first login auto-bootstraps)

### Post-Upgrade Auth Verification Checklist

- [ ] `AUTH_DISABLED` is NOT set in `~/.hermes/.env` or launcher script
- [ ] Server process environment does NOT contain `AUTH_DISABLED=1` (check `/proc/<pid>/environ`)
- [ ] `curl /api/auth/status` returns `{"hasPasswordLogin":true,"hasUsers":true}`
- [ ] `curl /api/auth/login` with valid credentials returns a JWT token (not auth disabled error)
- [ ] `curl /api/auth/me` with the JWT returns the correct user object
- [ ] Database path matches the mode you're running in (dev vs production)
- [ ] If `hasUsers` is `false`, either create the first account via login or insert directly into `users` + `user_profiles` tables

## Enforcing Username/Password Prompt on Every Access

When auth is enabled, the SPA can still auto-redirect away from the login page if a valid JWT exists in `localStorage`, or auto-login via a `?token=` URL parameter. To force every visit to prompt for username/password, apply these client-side changes.

### Changes Required

**File 1: `packages/client/src/router/index.ts` (remove login auto-redirect)**

Before (auto-redirects away from login if `hasApiKey()`):
```typescript
router.beforeEach((to, _from, next) => {
  if (to.meta.public) {
    if (to.name === 'login' && hasApiKey()) {
      next({ path: '/hermes/chat' })
      return
    }
    next()
    return
  }
  // ...
})
```

After (always show login page):
```typescript
router.beforeEach((to, _from, next) => {
  if (to.meta.public) {
    next()
    return
  }
  // ... rest unchanged
})
```

**File 2: `packages/client/src/views/LoginView.vue` (remove setup-time redirect)**

Remove or comment out:
```typescript
if (hasApiKey()) {
  router.replace("/hermes/chat");
}
```

**File 3: `packages/client/src/main.ts` (remove URL token injection)**

Remove or comment out:
```typescript
const urlParams = new URLSearchParams(window.location.search)
const hashQuery = window.location.hash.split('?')[1]
const urlToken = urlParams.get('token') || (hashQuery ? new URLSearchParams(hashQuery).get('token') : null)
if (urlToken) {
  (window as any).__LOGIN_TOKEN__ = urlToken
}
```

**File 4: `packages/client/src/api/client.ts` (add JWT expiry validation to `hasApiKey`)**

Before:
```typescript
export function hasApiKey(): boolean {
  return !!getApiKey()
}
```

After:
```typescript
export function hasApiKey(): boolean {
  const token = getApiKey()
  if (!token) return false
  // Validate JWT expiry on client side (server also checks it, but this prevents stale redirects)
  try {
    const payload = token.split('.')[1]
    if (!payload) return false
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/')
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=')
    const data = JSON.parse(atob(padded)) as { exp?: number }
    if (typeof data.exp !== 'number') return false
    if (Math.floor(Date.now() / 1000) >= data.exp) {
      clearApiKey()
      return false
    }
  } catch {
    return false
  }
  return true
}
```

Also update `getStoredUserRole()` to guard with `hasApiKey()` first:
```typescript
export function getStoredUserRole(): StoredUserRole | null {
  if (!hasApiKey()) return null
  const token = getApiKey()
  // ... rest unchanged
}
```

### Build Verification

After making the above changes, rebuild and verify the compiled JS does NOT contain the removed patterns:

```bash
cd /mnt/c/Users/thadd/hermes-web-ui && npm run build
# Then scan dist/
for pat in "__LOGIN_TOKEN__" "urlParams.get('token')" "router.replace(\"\"/hermes/chat\"\")"; do
  grep -r "$pat" dist/client/assets/js/ && echo "  FOUND (unexpected): $pat" || echo "  NOT FOUND (good): $pat"
done
```

### Server-Side Note

The static HTML at `/` is always served publicly (required for the SPA to load). Auth enforcement happens at:
1. **API routes** via `requireAuth` / `requireUserJwt` middleware (401 for missing/invalid tokens)
2. **SPA router** via `router.beforeEach` (redirects unauthenticated to login)
3. **Login page** no longer auto-redirects away when a token exists

## references/
- `references/session-2026-05-23-icons-messed-up-diagnostic.md` — Full diagnostic workflow for "icons messed up" reports: workspace deletion vs. git staged changes vs. browser cache.
- `references/spock-customization-inventory.md` — Full list of every customized file and what it does.
- `references/backup-creation.md` — How to create a complete restorable backup of the WebUI without node_modules, including verification checklist and Spock Guardian hook quirks.
- `references/session-2026-05-24-uninstall-cascade-recovery.md` — OpenClaw uninstall wiped `~/.hermes/spock-protector/`, causing silent favicon regression. Recovery steps, SHA256s, and the lesson: never trust a backup in a directory an installer can delete. Includes post-uninstall verification commands and thinking-videos dist check.
- `references/session-2026-05-24-v060-upgrade-postrewrite-hook-fix.md` — **CRITICAL**: `post-rewrite` hook fired during rebase and overwrote `AppSidebar.vue` with stale version, removing upstream `isSuperAdmin` and performance menu. Documents correct hook disable checklist (must disable `post-checkout`, `post-merge`, AND `post-rewrite`), and the rewritten hook that skips during rebase and uses file backups instead of `git checkout`.
