# Python Bridge Dependency Mismatch

## Error Transcripts

When the WebUI's Python agent bridge uses system Python instead of the hermes-agent venv Python, chat requests fail with cascading missing-module errors:

### Error: `No module named 'dotenv'`
```json
{"level":40,"time":1779610215939,"pid":405,"hostname":"Laptop","name":"bridge","durationMs":4,"runtime":{"profile":"devteam","cwd":"/mnt/c/Users/thadd/hermes-web-ui","profile_dir":"/home/thadd/.hermes/profiles/devteam","config_path":"/home/thadd/.hermes/profiles/devteam/config.yaml"},"response":{"ok":false,"error":"No module named 'dotenv'"},"msg":"[agent-bridge-client] request rejected"}
```

### Error: `No module named 'httpx'`
```json
{"level":40,"time":1779616310041,"pid":14411,"hostname":"Laptop","name":"bridge","durationMs":10015,"runtime":{"profile":"devteam","cwd":"/mnt/c/Users/thadd/hermes-web-ui","profile_dir":"/home/thadd/.hermes/profiles/devteam","config_path":"/home/thadd/.hermes/profiles/devteam/config.yaml"},"response":{"ok":false,"error":"No module named 'httpx'"},"msg":"[agent-bridge-client] request rejected"}
```

### Error: `Failed to initialize OpenAI client: No module named 'openai'`
```json
{"level":40,"time":1779616586299,"pid":14932,"hostname":"Laptop","err":{"type":"gY","message":"Failed to initialize OpenAI client: No module named 'openai'","stack":"Error: Failed to initialize OpenAI client: No module named 'openai'\n    at c (/mnt/c/Users/thadd/hermes-web-ui/dist/server/index.js:511:71)\n    ...","response":{"ok":false,"error":"Failed to initialize OpenAI client: No module named 'openai'","error_type":"RuntimeError"}},"msg":"[context-compress] session=mpjldswl2mvbkt: full context token estimate failed; using message-only estimate"}
```

### Broken pipe from dead worker
When the worker crashes mid-request, the bridge broker sees:
```json
{"level":40,"time":1779616323202,"pid":14411,"hostname":"Laptop","name":"bridge","durationMs":567,"runtime":{...},"response":{"ok":false,"error":"[Errno 32] Broken pipe"},"msg":"[agent-bridge-client] request rejected"}
```

## Diagnosis

**Check which Python the bridge is using:**
```bash
ps -ef | grep hermes_bridge | grep -v grep
```

Bad output (system Python):
```
thadd  15173  15146  0 04:57 ?  00:00:00 python3 /mnt/c/Users/thadd/hermes-web-ui/dist/server/agent-bridge/hermes_bridge.py --endpoint ipc:///tmp/hermes-agent-bridge.sock
```

Good output (venv Python):
```
thadd  14960  14932  0 04:54 ?  00:00:00 /home/thadd/.hermes/hermes-agent/venv/bin/python /mnt/c/Users/thadd/hermes-web-ui/dist/server/agent-bridge/hermes_bridge.py --endpoint ipc:///tmp/hermes-agent-bridge.sock
```

**Check if the venv has the missing packages:**
```bash
/home/thadd/.hermes/hermes-agent/venv/bin/python -c "import dotenv, httpx, openai; print('OK')"
```

**Check bridge log for the actual error:**
```bash
cat /home/thadd/.hermes/profiles/devteam/home/.hermes-web-ui/logs/bridge.log | tail -n 20
cat /home/thadd/.hermes/profiles/devteam/home/.hermes-web-ui/logs/server.log | grep -E 'agent-bridge.*request rejected|No module named'
```

## Cleanup — Kill Stale Bridge Processes

Failed workers from prior runs accumulate. Clean them before restart:

```bash
# Kill ALL hermes_bridge processes (brokers + workers)
for pid in $(ps -ef | grep hermes_bridge | grep -v grep | awk '{print $2}'); do
    kill -9 $pid 2>/dev/null
done

# Verify
ps -ef | grep hermes_bridge | grep -v grep
# Should return nothing

# Remove stale IPC sockets
rm -f /tmp/hermes-agent-bridge.sock
rm -rf /tmp/hermes-agent-bridge-workers/
```

## Fix — One-Time (Immediate)

```bash
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/.hermes/hermes-agent/venv/bin/python
cd /mnt/c/Users/thadd/hermes-web-ui
node bin/hermes-web-ui.mjs stop  # if running
node bin/hermes-web-ui.mjs start
```

## Permanent Fix — Launcher Updates

### Desktop `.bat` launcher (`Desktop/Hermes/Launch Hermes WebUI.bat`)
Change the WSL command line from:
```
wsl bash -lc 'cd /mnt/c/Users/thadd/hermes-web-ui && unset AUTH_DISABLED && nohup node bin/hermes-web-ui.mjs start > ~/.hermes-web-ui/server.log 2>&1 &'
```
To:
```
wsl bash -lc 'export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/.hermes/hermes-agent/venv/bin/python && cd /mnt/c/Users/thadd/hermes-web-ui && unset AUTH_DISABLED && nohup node bin/hermes-web-ui.mjs start > ~/.hermes-web-ui/server.log 2>&1 &'
```

### Watchdog script (`~/.hermes/scripts/hermes-watchdog.sh`)
Add the export before the WebUI restart block:
```bash
export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/.hermes/hermes-agent/venv/bin/python
cd /mnt/c/Users/thadd/hermes-web-ui || exit 1
nohup node bin/hermes-web-ui.mjs start > "$HOME/.hermes/logs/webui_watchdog_restart.log" 2>&1 &
```

### Shell profile (`~/.bashrc`)
```bash
echo 'export HERMES_AGENT_BRIDGE_PYTHON=/home/thadd/.hermes/hermes-agent/venv/bin/python' >> ~/.bashrc
```

## Why Not Install Into System Python?

You *can* do `sudo pip3 install --break-system-packages python-dotenv httpx openai`, but:
- Every future system Python upgrade (3.14 → 3.15) breaks it again
- New hermes-agent dependencies will require repeating the whack-a-mole
- `--break-system-packages` is explicitly discouraged by PEP 668

The venv at `~/.hermes/hermes-agent/venv` is maintained by hermes-agent's own setup and always has the correct package set.

## Root Cause

The WebUI's `hermes_bridge.py` uses `sys.executable` (the Python that launched it) to spawn worker processes. When the Node.js server spawns the bridge broker, it uses whatever `python3` is on PATH — typically `/usr/bin/python3` (system Python). The broker then spawns workers with the same Python. If that Python was upgraded and its site-packages don't contain hermes-agent's dependencies, every worker crashes.

The `HERMES_AGENT_BRIDGE_PYTHON` env variable overrides this path, forcing the broker and all workers to use the hermes-agent venv Python instead.

## Related

- SKILL.md section "Python bridge: No module named 'X'"
- `references/auth-debugging.md` for `.env` token hygiene
