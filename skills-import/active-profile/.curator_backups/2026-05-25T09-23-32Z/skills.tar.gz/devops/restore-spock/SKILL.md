---
title: Restore Spock WebUI Customizations
name: restore-spock
trigger: |
  When Spock customizations in the hermes-web-ui have been lost, overwritten,
  corrupted, or need to be re-applied after an upgrade, sync, or clean build.
  Also triggers on "restore spock", "fix spock", "re-apply spock", or any
  request to restore branding/avatar/sidebar/title customizations.
description: |
  Restores all Spock customizations to the hermes-web-ui at
  /mnt/c/Users/thadd/hermes-web-ui. This is a surgical restoration that
  re-applies only the known Spock changes without touching upstream code.
  Can be run after any upgrade, rebase, or build to ensure customizations
  survive.
---

# Restore Spock WebUI Customizations

## When to Run

- After an upgrade/rebase that may have overwritten customizations
- After `git reset --hard` or `git clean -fd`
- After a fresh `npm install` + `npm run build` that lost compiled patches
- When the Spock avatar, logo, sidebar text, or browser title is missing
- After the Spock Guardian hook fails to restore everything
- **Before any upgrade/rebase** — verify `f636b1b` and `9caac49` exist first

## Spock Customization Inventory

| # | File | What It Does | Restore Source |
|---|------|-------------|---------------|
| 1 | `packages/client/public/spock-avatar.png` | Spock avatar image for session list | `git show d37f88e` or backup |
| 2 | `packages/client/public/favicon.ico` | Browser tab icon (multi-res Spock ICO) | Convert from spock-avatar.png |
| 3 | `packages/client/public/favicon.png` | Browser tab icon (PNG backup) | `git show 5c0bd0b` or backup |
| 4 | `packages/client/src/components/hermes/chat/SessionListItem.vue` | Renders Spock avatar instead of multiavatar | `git show d37f88e` |
| 5 | `packages/client/index.html` | Browser tab title = "Spock" | `git show f636b1b` |
| 6 | `packages/client/public/logo.png` | Spock logo (public asset) | `git show f636b1b` |
| 7 | `packages/client/src/assets/logo.png` | Spock logo (bundled asset) | `git show f636b1b` |
| 8 | `packages/client/src/assets/thinking-dark.mp4` | Spock thinking animation | `git show f636b1b` |
| 9 | `packages/client/src/assets/thinking-light.mp4` | Spock thinking animation | `git show f636b1b` |
| 10 | `packages/client/src/components/layout/AppSidebar.vue` | Sidebar shows "Spock" text + logo | `git show f636b1b` |
| 11 | `vite.config.website.ts` | Website build customization | `git show f636b1b` |
| 12 | `dist/client/spock-avatar.png` | Compiled asset | Copy from `packages/client/public/` |
| 13 | `dist/client/favicon.ico` | Compiled tab icon | Copy from `packages/client/public/` |
| 14 | `dist/client/assets/js/OutlinePanel-CBYfEuCP.js` | Compiled JS with Spock img | Patch manually |
| 15 | `dist/client/assets/js/OutlinePanel-P0pfhZX2.js` | Compiled JS with Spock img | Patch manually |

## Restoration Procedure

### Step 0: Verify Base Commits Exist (ABORT if missing)

The authoritative Spock customizations live in two commits. If these are gone
from git history, the restoration must use the backup path instead.

```bash
cd /mnt/c/Users/thadd/hermes-web-ui
for commit in f636b1b 9caac49; do
  git cat-file -t "$commit" > /dev/null 2>&1 && echo "✓ $commit exists" || echo "✗ $commit MISSING"
done
```

If any commit is **MISSING**, skip directly to **Step 5: Restore from Backup**.

### Step 1: Check Current State
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
echo "=== Checking Spock customizations ==="
grep -q "spock-avatar.png" packages/client/src/components/hermes/chat/SessionListItem.vue 2>/dev/null && echo "✓ SessionListItem" || echo "✗ SessionListItem MISSING"
grep -q "Spock" packages/client/src/components/layout/AppSidebar.vue 2>/dev/null && echo "✓ AppSidebar" || echo "✗ AppSidebar MISSING"
grep -q "Spock" packages/client/index.html 2>/dev/null && echo "✓ index.html" || echo "✗ index.html MISSING"
ls packages/client/public/spock-avatar.png 2>/dev/null && echo "✓ spock-avatar.png" || echo "✗ spock-avatar.png MISSING"
ls dist/client/spock-avatar.png 2>/dev/null && echo "✓ dist spock-avatar.png" || echo "✗ dist spock-avatar.png MISSING"
```

### Step 2: Restore Source Files from Git History

These commits contain the authoritative Spock customizations:
- `f636b1b` — Original rebrand (logo, title, sidebar, thinking videos)
- `d37f88e` — Spock avatar for session list (replaces multiavatar with static image)
- `5c0bd0b` — Favicon.png + sidebar CSS + all prior Spock branding

```bash
cd /mnt/c/Users/thadd/hermes-web-ui

# Restore f636b1b files (the rebrand)
git checkout f636b1b -- \
  packages/client/index.html \
  packages/client/public/logo.png \
  packages/client/src/assets/logo.png \
  packages/client/src/assets/thinking-dark.mp4 \
  packages/client/src/assets/thinking-light.mp4 \
  packages/client/src/components/layout/AppSidebar.vue \
  vite.config.website.ts

# Restore d37f88e files (the avatar)
git checkout d37f88e -- \
  packages/client/src/components/hermes/chat/SessionListItem.vue \
  packages/client/public/spock-avatar.png
```

### Step 3: Restore Compiled dist/ Files

The build system (`rolldown`) is broken, so we must patch `dist/` manually:

```bash
cd /mnt/c/Users/thadd/hermes-web-ui

# Copy spock-avatar.png to dist
cp packages/client/public/spock-avatar.png dist/client/spock-avatar.png

# Patch the compiled JS files for Spock avatar in session list
for fname in dist/client/assets/js/OutlinePanel-CBYfEuCP.js dist/client/assets/js/OutlinePanel-P0pfhZX2.js; do
  if [ -f "$fname" ]; then
    # Replace multiavatar span with Spock img
    python3 -c "
import re
with open('$fname', 'r') as f:
  content = f.read()
# Old pattern: n(\"span\",{class:\"session-item-profile-avatar\",innerHTML:e.value},null,8,z)
# New pattern: n(\"img\",{class:\"session-item-profile-avatar\",src:\"/spock-avatar.png\",alt:\"Spock\"},null,8,z)
content = content.replace(
  'n(\"span\",{class:\"session-item-profile-avatar\",innerHTML:e.value},null,8,z)',
  'n(\"img\",{class:\"session-item-profile-avatar\",src:\"/spock-avatar.png\",alt:\"Spock\"},null,8,z)'
)
# Fix the dynamic props array from ['innerHTML'] to ['src']
content = content.replace('z=[\"innerHTML\"]', 'z=[\"src\"]')
with open('$fname', 'w') as f:
  f.write(content)
"
    echo "Patched: $fname"
  fi
done
```

### Step 4: Verify Everything
```bash
cd /mnt/c/Users/thadd/hermes-web-ui
echo "=== Verification ==="
grep -q 'type:.*image.*dataUrl.*spock-avatar' packages/client/src/components/hermes/chat/SessionListItem.vue && echo "✓ SessionListItem.vue (object shape)" || echo "✗ FAIL — wrong avatar type"
grep -q "Spock" packages/client/src/components/layout/AppSidebar.vue && echo "✓ AppSidebar.vue" || echo "✗ FAIL"
grep -q "Spock" packages/client/index.html && echo "✓ index.html" || echo "✗ FAIL"
ls packages/client/public/spock-avatar.png && echo "✓ spock-avatar.png" || echo "✗ FAIL"
ls dist/client/spock-avatar.png && echo "✓ dist spock-avatar.png" || echo "✗ FAIL"
grep -q "spock-avatar" dist/client/assets/js/OutlinePanel-CBYfEuCP.js && echo "✓ OutlinePanel JS" || echo "✗ FAIL"
```

### Step 5: Restart Server
```bash
# Kill existing
pkill -f "node dist/server/index.js" || true
# Restart
cd /mnt/c/Users/thadd/hermes-web-ui && node dist/server/index.js &
```

## Alternative: Restore from Backup

If git history is lost, restore from the backup at:
`C:\Users\thadd\Documents\SpockWebUI`

```bash
# Full restore from backup
cp -r "/mnt/c/Users/thadd/Documents/SpockWebUI/"* "/mnt/c/Users/thadd/hermes-web-ui/"
# Then reinstall node_modules
cd /mnt/c/Users/thadd/hermes-web-ui && npm install
```

## If Customizations Are Still Missing

1. Check git reflog: `git reflog --all | head -20`
2. Check if commits `f636b1b` and `9caac49` exist: `git log --oneline | grep -i spock`
3. If commits are gone, restore from backup: `cp -r /mnt/c/Users/thadd/Documents/SpockWebUI /mnt/c/Users/thadd/hermes-web-ui/`
4. Re-apply changes manually using the commit diffs as reference

## references/
- `references/customization-commits.md` — Full diffs of f636b1b and 9caac49.
- `references/restore-from-backup.md` — Step-by-step backup restoration.
